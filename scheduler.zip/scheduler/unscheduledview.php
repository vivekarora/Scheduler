<?php

    /**
    * Security traps
    */
    if (!defined('MOODLE_INTERNAL')){
        error("This file cannot be loaded directly");
    }
/*
    if ($action){
        include('unscheduledview.controller.php');
    }
*/

    print_general_tabs($cm, $scheduler, 'unscheduled');

    $forcegroupappoint  = ( $cm->groupmode ? $scheduler->forcegroupappoint : 0 ); // ULPGC ecastro



//die;
/// print table of outstanding appointer (students)


echo '<center>
            <table width="90%">
            <tr valign="top">';

if($forcegroupappoint != 2) {
    echo '<td width="50%">';
    print_heading(get_string('schedulestudents', 'scheduler'));
    $students = get_users_by_capability ($context, 'mod/scheduler:appoint', 'u.id,lastname,firstname,email,picture', 'lastname');
    if (!$students) {
        $nostudentstr = get_string('noexistingstudents');
        if ($course->id == SITEID){
            $nostudentstr .= '<br/>'.get_string('howtoaddstudents','scheduler');
        }
        notify($nostudentstr);
    } else {
        $mtable->head  = array ('', $strname, $stremail, $straction);
        $mtable->align = array ('CENTER','LEFT','LEFT','CENTER');
        $mtable->width = array('', '', '', '');
        $mtable->data = array();
        // In $mailto the mailing list for reminder emails is built up
        $mailto = '<a href="mailto:';
        $date = usergetdate(time());
        foreach ($students as $student) {
            if (!scheduler_has_slot($student->id, $scheduler, true, $scheduler->schedulermode == 'onetime')) {
                $picture = print_user_picture($student->id, $course->id, $student->picture, false, true);
                $name = "<a href=\"../../user/view.php?id={$student->id}&amp;course={$scheduler->course}\">";
                $name .= fullname($student);
                $name .= '</a>';
                $email = obfuscate_mailto($student->email);
                if (scheduler_has_slot($student->id, $scheduler, true, false) == 0){
                    // student has never scheduled
                    $mailto .= $student->email.', ';
                }
                $checkbox = "<a href=\"view.php?what=schedule&amp;id={$cm->id}&amp;studentid={$student->id}&amp;page={$page}&amp;seen=1\">";
                $checkbox .= '<img src="pix/unticked.gif" border="0" />';
                $checkbox .= '</a>';
                $actions = '<span style="font-size: x-small;">';
                $actions .= "<a href=\"view.php?what=schedule&amp;id={$cm->id}&amp;studentid={$student->id}&amp;page={$page}\">";
                $actions .= get_string('schedule', 'scheduler');
                $actions .= '</a></span>';
                $mtable->data[] = array($picture, $name, $email, $actions);
            }
        }

        // dont print if allowed to book multiple appointments
        // There are students who still have to make appointments
        if (($num = count($mtable->data)) > 0) {

            // Print number of students who still have to make an appointment
            print_heading(get_string('missingstudents', 'scheduler', $num), 'center', 3);

            // Print links to print invitation or reminder emails
            $strinvitation = get_string('invitation', 'scheduler');
            $strreminder = get_string('reminder', 'scheduler');
            $mailto = rtrim($mailto, ', ');

            $subject = $strinvitation . ': ' . $scheduler->name;
            $body = $strinvitation . ': ' . $scheduler->name . "\n\n";
            $body .= get_string('invitationtext', 'scheduler');
            $body .= "{$CFG->wwwroot}/mod/scheduler/view.php?id={$cm->id}";
            echo '<center>'.get_string('composeemail', 'scheduler').
                $mailto.'?subject='.htmlentities(rawurlencode($subject)).
                '&amp;body='.htmlentities(rawurlencode($body)).
                '"> '.$strinvitation.'</a> ';

            $subject = $strreminder . ': ' . $scheduler->name;
            $body = $strreminder . ': ' . $scheduler->name . "\n\n";
            $body .= get_string('remindertext', 'scheduler');
            $body .= "{$CFG->wwwroot}/mod/scheduler/view.php?id={$cm->id}";
            echo $mailto.'?subject='.htmlentities(rawurlencode($subject)).
                '&amp;body='.htmlentities(rawurlencode($body)).
                '"> '.$strreminder.'</a></center><br />';

            // print table of students who still have to make appointments
            print_table($mtable);
        } else {
            notify(get_string('nostudents', 'scheduler'));
        }
    }
    echo '</td>';
}

if ($forcegroupappoint){
    echo '<td width="50%">';

/// print table of outstanding appointer (groups)
    $groups = groups_get_activity_allowed_groups($cm);
    //$groups = get_groups($COURSE->id);
    print_heading(get_string('schedulegroups', 'scheduler'));
    if (empty($groups)){
        notify(get_string('nogroups', 'scheduler'));
    } else {
        $mtable->head  = array ('', $strname, $straction);
        $mtable->align = array ('CENTER','LEFT','CENTER');
        $mtable->width = array('', '', '');
        $mtable->data = array();
        foreach($groups as $group){
            $members = get_group_users($group->id, 'lastname', '', 'u.id, lastname, firstname, email, picture');
            if (empty($members)) continue;
            if (!scheduler_has_slot(implode(',', array_keys($members)), $scheduler, true, $scheduler->schedulermode == 'onetime')) {
                $actions = '<span style="font-size: x-small;">';
                $actions .= "<a href=\"view.php?what=schedulegroup&amp;id={$cm->id}&amp;groupid={$group->id}&amp;page={$page}\">";
                $actions .= get_string('schedule', 'scheduler');
                $actions .= '</a></span>';
                $groupmembers = array();
                foreach($members as $member){
                    $groupmembers[] = fullname($member);
                }
                $groupcrew = '['. implode(", ", $groupmembers) . ']';
                $mtable->data[] = array('', $groups[$group->id]->name.' '.$groupcrew, $actions);
            }
        }
        // print table of students who still have to make appointments
        if (!empty($mtable->data)){
            print_table($mtable);
        } else {
            notify(get_string('nogroups', 'scheduler'));
        }
    }

    echo '</td>';
}
?>
    </tr>
</table>
<form action="<?php echo $CFG->wwwroot ?>/course/view.php" method="get">
<input type="hidden" name="id" value="<?php p($course->id) ?>" />
<input type="submit" name="go_btn" value="<?php print_string('return', 'scheduler') ?>" />
</form>
<center>