<?PHP // $Id: version.php,v 1.15 2009/10/02 16:23:04 diml Exp $

/**
* @package mod-scheduler
* @category mod
* @author Valery Fremaux 2.0
* @version 2.0
*/

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of scheduler
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2010101300;
$module->requires = 2010080300;  // Requires this Moodle version
$module->cron     = 60;

?>
