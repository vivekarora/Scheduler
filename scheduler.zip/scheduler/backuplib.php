<?php //$Id: backuplib.php,v 1.7 2009/07/29 19:05:39 diml Exp $

    /**
    * This php script contains all the stuff to backup/restore
    * scheduler mods
    *
    * @package mod-scheduler
    * @category mod
    * @author Valery Fremaux (admin@ethnoinformatique.fr)
    *
    */

    //This is the "graphical" structure of the scheduler mod:
    //
    //                     scheduler
    //                    (CL, pk->id)
    //                        |
    //                        |
    //                        |
    //                   scheduler_slots
    //               (UL, pk->id, fk->scheduler)
    //
    // Meaning: pk->primary key field of the table
    //          fk->foreign key to link with parent
    //          nt->nested field (recursive data)
    //          CL->course level info
    //          UL->user level info
    //          files->table may have files
    //
    //-----------------------------------------------------------

    /**
    * Includes and requires
    */
    include_once $CFG->dirroot.'/mod/scheduler/locallib.php';

    /**
    *
    */
    function scheduler_backup_mods($bf, $preferences) {
        global $DB;
        
        //Iterate over scheduler table
        $schedulers = $DB->get_records ('scheduler', array('course' => $preferences->backup_course), 'id');
        if ($schedulers) {
            foreach ($schedulers as $scheduler) {
                scheduler_backup_one_mod($bf, $preferences, $scheduler);
            }
        }
    }

    /**
    *
    */
    function scheduler_backup_one_mod($bf, $preferences, $scheduler) {
        global $CFG, $DB;

        if (is_numeric($scheduler)) {
            $scheduler = $DB->get_record('scheduler', array('id' => $scheduler));
        }

        $status = true;

        //Start mod
        $status = $status && fwrite ($bf, start_tag('MOD', 3, true));
        //Print scheduler data
        fwrite ($bf, full_tag('ID', 4, false, $scheduler->id));
        fwrite ($bf, full_tag('MODTYPE', 4, false, 'scheduler'));
        fwrite ($bf, full_tag('NAME', 4, false, $scheduler->name));
        fwrite ($bf, full_tag('DESCRIPTION', 4, false, $scheduler->description));
        fwrite ($bf, full_tag('FORCEGROUPAPPOINT', 4, false, $scheduler->forcegroupappoint));
        fwrite ($bf, full_tag('AUTOMATICSLOTS', 4, false, $scheduler->automaticslots));
        fwrite ($bf, full_tag('SCALE', 4, false, $scheduler->scale));
        fwrite ($bf, full_tag('GRADINGSTRATEGY', 4, false, $scheduler->gradingstrategy));
        fwrite ($bf, full_tag('STAFFROLENAME', 4, false, $scheduler->staffrolename));
        fwrite ($bf, full_tag('SCHEDULERMODE', 4, false, $scheduler->schedulermode));
        fwrite ($bf, full_tag('REUSEGUARDTIME', 4, false, $scheduler->reuseguardtime));
        fwrite ($bf, full_tag('DEFAULTSLOTDURATION', 4, false, $scheduler->defaultslotduration));
        fwrite ($bf, full_tag('ALLOWNOTIFICATIONS', 4, false, $scheduler->allownotifications));
        fwrite ($bf, full_tag('TIMEMODIFIED', 4, false, $scheduler->timemodified));

        //if we've selected to backup users info, then execute backup_scheduler_slots and appointments
        if ($preferences->mods['scheduler']->userinfo) {
            $scheduler_slots = $DB->get_records('scheduler_slots', array('schedulerid' => $scheduler->id), 'id');
            $status = $status && backup_scheduler_slots($bf, $preferences, $scheduler->id, $scheduler_slots);

            $status = $status && backup_scheduler_appointments($bf, $preferences, $scheduler_slots);

            $scheduler_autoslots = $DB->get_records('scheduler_automaticslots', array('schedulerid' => $scheduler->id), 'id');
            $status = $status && backup_scheduler_automaticslots($bf, $preferences, $scheduler->id, $scheduler_autoslots);


        }
        //End mod
        $status = $status && fwrite($bf, end_tag('MOD', 3, true));
        return $status;
    }

    /**
    * Backup scheduler_slots contents (executed from scheduler_backup_mods)
    */
    function backup_scheduler_slots ($bf, $preferences, $schedulerid, $slots) {
        global $CFG;

        $status = true;

        //If there is slots
        if ($slots) {
            //Write start tag
            $status = $status && fwrite ($bf, start_tag('SLOTS', 4, true));
            //Iterate over each slot
            foreach ($slots as $slot) {
                //Start slot
                $status = $status && fwrite ($bf, start_tag('SLOT', 5, true));
                //Print scheduler_slots contents
                fwrite ($bf, full_tag('ID', 6, false, $slot->id));
                fwrite ($bf, full_tag('SCHEDULERID', 6, false, $schedulerid));
                fwrite ($bf, full_tag('STARTTIME', 6, false, $slot->starttime));
                fwrite ($bf, full_tag('DURATION', 6, false, $slot->duration));
                fwrite ($bf, full_tag('TEACHERID', 6, false, $slot->teacherid));
                fwrite ($bf, full_tag('APPOINTMENTLOCATION', 6, false, $slot->appointmentlocation));
                fwrite ($bf, full_tag('REUSE', 6, false, $slot->reuse));
                fwrite ($bf, full_tag('TIMEMODIFIED', 6, false, $slot->timemodified));
                fwrite ($bf, full_tag('NOTES', 6, false, $slot->notes));
                fwrite ($bf, full_tag('EXCLUSIVITY', 6, false, $slot->exclusivity));
                fwrite ($bf, full_tag('GROUPID', 6, false, $slot->groupid));
                fwrite ($bf, full_tag('EMAILDATE', 6, false, $slot->emaildate));
                fwrite ($bf, full_tag('HIDEUNTIL', 6, false, $slot->hideuntil));
                //End slot
                $status = $status && fwrite ($bf, end_tag('SLOT', 5, true));
            }
            //Write end tag
            $status = $status && fwrite($bf, end_tag('SLOTS', 4, true));
        }
        return $status;
    }

    /**
    * Backup scheduler_automaticslots contents (executed from scheduler_backup_mods)
    */
    function backup_scheduler_automaticslots ($bf, $preferences, $schedulerid, $slots) {
        global $CFG;

        $status = true;

        //If there is slots
        if ($slots) {
            //Write start tag
            $status = $status && fwrite ($bf, start_tag('AUTOSLOTS', 4, true));
            //Iterate over each slot
            foreach ($slots as $slot) {
                //Start slot
                $status = $status && fwrite ($bf, start_tag('AUTOSLOT', 5, true));
                //Print scheduler_slots contents
                fwrite ($bf, full_tag('ID', 6, false, $slot->id));
                fwrite ($bf, full_tag('SCHEDULERID', 6, false, $schedulerid));
                fwrite ($bf, full_tag('STARTTIME', 6, false, $slot->starttime));
                fwrite ($bf, full_tag('DURATION', 6, false, $slot->duration));
                fwrite ($bf, full_tag('TEACHERID', 6, false, $slot->teacherid));
                fwrite ($bf, full_tag('APPOINTMENTLOCATION', 6, false, $slot->appointmentlocation));
                fwrite ($bf, full_tag('TIMEMODIFIED', 6, false, $slot->timemodified));
                fwrite ($bf, full_tag('EXCLUSIVITY', 6, false, $slot->exclusivity));
                //End slot
                $status = $status && fwrite ($bf, end_tag('AUTOSLOT', 5, true));
            }
            //Write end tag
            $status = $status && fwrite($bf, end_tag('AUTOSLOTS', 4, true));
        }
        return $status;
    }



    /**
    * Backup scheduler_slots appointments (executed from scheduler_backup_mods)
    */
    function backup_scheduler_appointments($bf, $preferences, $slots) {
        global $CFG, $DB;

        $status = true;

        if(!$slots) {
            return $status;
        }

        list($usql, $params) = $DB->get_in_or_equal($slots); // IN
        $appointments = $DB->get_records_select('scheduler_appointment', "slotid $usql ", $params);

        if ($appointments) {
            //Write start tag
            $status = $status && fwrite ($bf, start_tag('APPOINTMENTS', 4, true));
            //Iterate over each appointment
            foreach ($appointments as $appointment) {
                //Start slot
                $status = $status && fwrite ($bf, start_tag('APPOINTMENT', 5, true));
                //Print appointment data
                fwrite ($bf, full_tag('ID', 6, false, $appointment->id));
                fwrite ($bf, full_tag('SLOTID', 6, false, $appointment->slotid));
                fwrite ($bf, full_tag('STUDENTID', 6, false, $appointment->studentid));
                fwrite ($bf, full_tag('ATTENDED', 6, false, $appointment->attended));
                fwrite ($bf, full_tag('GRADE', 6, false, $appointment->grade));
                fwrite ($bf, full_tag('APPOINTMENTNOTE', 6, false, $appointment->appointmentnote));
                fwrite ($bf, full_tag('TIMECREATED', 6, false, $appointment->timecreated));
                fwrite ($bf, full_tag('TIMEMODIFIED', 6, false, $appointment->timemodified));
                //End appointment
                $status = $status && fwrite ($bf, end_tag('APPOINTMENT', 5, true));
            }
            //Write end tag
            $status = $status && fwrite($bf, end_tag('APPOINTMENTS', 4, true));
        }

        return $status;
    }

    /**
    * Return an array of info (name, value)
    */
   function scheduler_check_backup_mods($course, $user_data=false, $backup_unique_code) {
        //First the course data
        $info[0][0] = get_string('modulenameplural', 'scheduler');
        if ($ids = scheduler_ids ($course)) {
            $info[0][1] = count($ids);
        } else {
            $info[0][1] = 0;
        }

        //Now, if requested, the user_data
        if ($user_data) {
            $info[1][0] = get_string('slots', 'scheduler');
            if ($ids = scheduler_slot_ids_by_course ($course)) {
                $info[1][1] = count($ids);
            } else {
                $info[1][1] = 0;
            }
            $info[2][0] = get_string('appointments', 'scheduler');
            if ($ids = scheduler_appointments_ids_by_course($course)) {
                $info[2][1] = count($ids);
            } else {
                $info[2][1] = 0;
            }
            $info[3][0] = get_string('automaticslots', 'scheduler');
            if ($ids = scheduler_automaticslots_ids_by_course($course)) {
                $info[3][1] = count($ids);
            } else {
                $info[3][1] = 0;
            }

        }
        return $info;
    }

    // INTERNAL FUNCTIONS. BASED IN THE MOD STRUCTURE

    /**
    * Returns an array of schedulers id
    */
    function scheduler_ids ($course) {
        global $CFG, $DB;

        $sql = "
            SELECT
                s.id,
                s.course
            FROM
                {scheduler} AS s
            WHERE
                s.course = ?
        ";
        return $DB->get_records_sql ($sql, array($course));
    }

    /**
    * Returns an array of scheduler slots id
    */
    function scheduler_slot_ids_by_course ($course) {
        global $CFG, $DB;

        $sql = "
            SELECT
                sl.id ,
                sl.schedulerid
            FROM
                {scheduler_slots} AS sl,
                {scheduler} AS s
            WHERE
                s.course = ? AND
                sl.schedulerid = s.id
        ";
        return $DB->get_records_sql($sql, array($course));
    }


/**
    * Returns an array of scheduler atomatic slots id
    */
    function scheduler_automaticslots_ids_by_course ($course) {
        global $CFG, $DB;

        $sql = "
            SELECT
                sl.id ,
                sl.schedulerid
            FROM
                {scheduler_automaticslots} AS sl,
                {scheduler} AS s
            WHERE
                s.course = ? AND
                sl.schedulerid = s.id
        ";
        return $DB->get_records_sql($sql, array($course));
    }



    /**
    * Returns an array of scheduler appointments id
    */
    function scheduler_appointments_ids_by_course ($course) {
        global $CFG, $DB;

        $sql = "
            SELECT
                a.id,
                sl.schedulerid
            FROM
                {scheduler_appointment} AS a,
                {scheduler_slots} AS sl,
                {scheduler} AS s
            WHERE
                s.course = ? AND
                sl.schedulerid = s.id AND
                sl.id = a.slotid
        ";
        return $DB->get_records_sql($sql, array($course));
    }
?>