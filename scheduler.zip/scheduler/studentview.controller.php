<?php

/**
* Controller for student view
*
* @package mod-scheduler
* @category mod
* @author Gustav Delius, Valery Fremaux > 1.8
*
* @usecase 'savechoice'
* @usecase 'disengage'
*/

if (!defined('MOODLE_INTERNAL')){
    die('Direct access to this script is forbidden!');
}

$forcegroupappoint  = ( $groupmode ? $scheduler->forcegroupappoint : 0 ); // ULPGC ecastro

/************************************************ Saving choice ************************************************/
if ($action == 'savechoice') {
    // get parameters
    $slotid       = optional_param('slotid', '', PARAM_INT);
    $appointgroup = optional_param('appointgroup', 0, PARAM_INT);
    $appointnote  = optional_param('appointnote', '', PARAM_TEXT);

    if (!$slotid) {
        notice(get_string('notselected', 'scheduler'), "view.php?id={$cm->id}");
    }

    if (!$slot = $DB->get_record('scheduler_slots', array('id' => $slotid))) {
        print_error('errorinvalidslot', 'scheduler');
    }

    $available = scheduler_get_appointments($slotid);
    $consumed = ($available) ? count($available) : 0 ;

    // if slot is already overcrowded
    if ($slot->exclusivity > 0 && $slot->exclusivity <= $consumed) {
       if ($updating = $DB->count_records('scheduler_appointment', array('slotid' => $slot->id, 'studentid' => $USER->id))) {
        $message = get_string('alreadyappointed', 'scheduler');
       } else {
        $message = get_string('slot_is_just_in_use', 'scheduler');
       }
       print_box_start('error');
       echo $message;
       print_continue("{$CFG->wwwroot}/mod/scheduler/view.php?id={$cm->id}");
       print_box_end();
       print_footer($course);
       exit();
    }

    /// If we are scheduling a full group we must discard all pending appointments of other participants of the scheduled group
    /// just add the list of other students for searching slots to delete
    if ($appointgroup){
        if (!function_exists('build_navigation')){
            // we are still in 1.8
            $oldslotownersarray = groups_get_members($appointgroup, 'student');
        } else {
            // we are still in 1.8
            $oldslotownersarray = groups_get_members($appointgroup);
        }
        // special hack for 1.8 / 1.9 compatibility for groups_get_members()
        foreach($oldslotownersarray as $oldslotownermember){
            if (is_numeric($oldslotownermember)){
                // we are in 1.8
                if (has_capability("mod/scheduler:appoint", $context, $oldslotownermember)){
                    $oldslotowners[] = $oldslotownermember;
                }
            } else {
                // we are in 1.9
                if (has_capability("mod/scheduler:appoint", $context, $oldslotownermember->id)){
                    $oldslotowners[] = $oldslotownermember->id;
                }
            }
        }
    } else {
        // single user appointment : get current user in
        $oldslotowners[] = $USER->id;
    }

    /// cleans up old slots if not attended (attended are definitive results, with grades)

    //this code is buggy because ids : moodle get_records will mangle array if identical values in first column (only returns unique values)
    // slot ids are identical for group appoinments: only one gets selected not all
    // if appoinmentid, really unique is first the problem is solved

    list($usql, $params) = $DB->get_in_or_equal($oldslotowners);

    $sql = "
        SELECT
            a.id as appointmentid,
            s.*
        FROM
            {scheduler_slots} s,
            {scheduler_appointment} a
        WHERE
            s.id = a.slotid AND
            s.schedulerid = {$slot->schedulerid} AND
            a.studentid $usql AND
            a.attended = 0
    ";
    if ($scheduler->schedulermode == 'onetime'){
        $sql .= " AND s.starttime > ".time();
    }

    if ($oldappointments = $DB->get_records_sql($sql, $params)){
        foreach($oldappointments as $oldappointment){
            scheduler_delete_appointment($oldappointment->appointmentid, $oldappointment, $scheduler);

            // notify teacher
            if ($scheduler->allownotifications){
                $student = $DB->get_record('user', array('id' => $USER->id));
                $teacher = $DB->get_record('user', array('id' => $oldappointment->teacherid));
                include_once($CFG->dirroot.'/mod/scheduler/mailtemplatelib.php');
                $vars = array( 'SITE' => $SITE->shortname,
                               'SITE_URL' => $CFG->wwwroot,
                               'COURSE_SHORT' => $COURSE->shortname,
                               'COURSE' => $COURSE->fullname,
                               'COURSE_URL' => $CFG->wwwroot.'/course/view.php?id='.$COURSE->id,
                               'MODULE' => $scheduler->name,
                               'USER' => fullname($student),
                               'DATE' => userdate($oldappointment->starttime,get_string('strftimedate')),   // BUGFIX CONTRIB-937
 	                           'TIME' => userdate($oldappointment->starttime,get_string('strftimetime')),   // BUGFIX end
                               'DURATION' => $oldappointment->duration );
                $notification = compile_mail_template('cancelled', $vars );
                $notificationHtml = compile_mail_template('cancelled_html', $vars );
                email_to_user($teacher, $student, get_string('cancelledbystudent', 'scheduler', $SITE->shortname), $notification, $notificationHtml);
            }

            // delete all calendar events for that slot
            scheduler_delete_calendar_events($oldappointment);
            // renew all calendar events as some appointments may be left for other students
            scheduler_add_update_calendar_events($oldappointment, $course);
        }
    }

    /// if forcegroupmode: add groupid to the slot
    if ($appointgroup && $forcegroupappoint == 2){
        $DB->set_field('scheduler_slots', 'groupid', $appointgroup, array('id' => $slotid));
        $slot->groupid = $appointgroup;
    }

    /// create new appointment and add it for each member of the group
    foreach($oldslotowners as $astudentid){
        $appointment->slotid = $slotid;
        $appointment->appointmentnote = addslashes($appointnote);
        $appointment->studentid = $astudentid;
        $appointment->attended = 0;
        $appointment->timecreated = time();
        $appointment->timemodified = time();
        if (!$DB->insert_record('scheduler_appointment', $appointment)) {
           print_error('errorcantinsert', 'scheduler', get_string('appointement', 'scheduler'));
        }
        scheduler_events_update($slot, $course);

        // notify teacher
        if ($scheduler->allownotifications){
            $student = $DB->get_record('user', array('id' => $appointment->studentid));
            $teacher = $DB->get_record('user', array('id' => $slot->teacherid));
            include_once($CFG->dirroot.'/mod/scheduler/mailtemplatelib.php');
            $vars = array( 'SITE' => $SITE->shortname,
                           'SITE_URL' => $CFG->wwwroot,
                           'COURSE_SHORT' => $COURSE->shortname,
                           'COURSE' => $COURSE->fullname,
                           'COURSE_URL' => $CFG->wwwroot.'/course/view.php?id='.$COURSE->id,
                           'MODULE' => $scheduler->name,
                           'USER' => fullname($student),
                           'DATE' => userdate($slot->starttime,get_string('strftimedate')),   // BUGFIX CONTRIB-937
                           'TIME' => userdate($slot->starttime,get_string('strftimetime')),   // BUGFIX end
                           'DURATION' => $slot->duration );
            $notification = compile_mail_template('applied', $vars );
            $notificationHtml = compile_mail_template('applied_html', $vars );
            email_to_user($teacher, $student, get_string('newappointment', 'scheduler', $SITE->shortname), $notification, $notificationHtml);
        }
    }
}
// *********************************** Disengage alone from the slot ******************************/
if ($action == 'disengage') {
    // get parameters
    $appointgroup = optional_param('appointgroup', 0, PARAM_INT);

    // get all users either alone or as group
    if($appointgroup) {
        $appointees = array_keys(groups_get_members($appointgroup, 'u.id'));
    } else {
        $appointees = array($USER->id);
    }

    list($usql, $params) = $DB->get_in_or_equal($appointees);
    $userselect = " 
        studentid $usql AND 
        attended = 0
    ";
    $appointments = $DB->get_records_select('scheduler_appointment', $userselect, $params);

    if ($appointments){
        foreach($appointments as $appointment){
            $oldslot = $DB->get_record('scheduler_slots', array('id' => $appointment->slotid));
            scheduler_delete_appointment($appointment->id, $oldslot, $scheduler);

            // notify teacher
            if ($scheduler->allownotifications){
                $student = $DB->get_record('user', array('id' => $USER->id));
                $teacher = $DB->get_record('user', array('id' => $oldslot->teacherid));
                include_once($CFG->dirroot.'/mod/scheduler/mailtemplatelib.php');
                $vars = array( 'SITE' => $SITE->shortname,
                               'SITE_URL' => $CFG->wwwroot,
                               'COURSE_SHORT' => $COURSE->shortname,
                               'COURSE' => $COURSE->fullname,
                               'COURSE_URL' => $CFG->wwwroot.'/course/view.php?id='.$COURSE->id,
                               'MODULE' => $scheduler->name,
                               'USER' => fullname($student),
                               'DATE' => userdate($oldslot->starttime,get_string('strftimedate')),   // BUGFIX CONTRIB-937
 	                           'TIME' => userdate($oldslot->starttime,get_string('strftimetime')),   // BUGFIX end
                               'DURATION' => $oldslot->duration );
                $notification = compile_mail_template('cancelled', $vars );
                $notificationHtml = compile_mail_template('cancelled_html', $vars );
                email_to_user($teacher, $student, get_string('cancelledbystudent', 'scheduler', $SITE->shortname), $notification, $notificationHtml);
            }
        }

        // delete calendar events for that slot
        scheduler_delete_calendar_events($oldslot);
        // renew all calendar events as some appointments may be left for other students
        scheduler_add_update_calendar_events($oldslot, $course);
    }
}
// *********************************** UPDATE notes alone from the slot ******************************/
if ($action == 'updateappnote') {
    // get parameters
    $slotid         = optional_param('slotid', '', PARAM_INT);
    $appointgroup   = optional_param('appointgroup', 0, PARAM_INT);
    $appointnote    = optional_param('appointnote', '', PARAM_TEXT);

    if (!$slotid) {
        notice(get_string('notselected', 'scheduler'), "view.php?id={$cm->id}");
    }

    if (!$slot = $DB->get_record('scheduler_slots', array('id', $slotid))) {
        print_error('errorinvalidslot', 'scheduler');
    }

    // get all users either alone or as group
    if($appointgroup) {
        $appointees = array_keys(groups_get_members($appointgroup, 'u.id'));
    } else {
        $appointees = array($USER->id);
    }

    list($usql, $params) = $DB->get_in_or_equal($appointees);
    $select = " slotid = {$slotid} AND studentid $usql ";

    if($appointments = $DB->get_records_select('scheduler_appointment', $select, $params)) {
        foreach($appointments as $appointment) {
            $appointment->appointmentnote = $appointnote;
            if (!$DB->update_record('scheduler_appointment', $appointment)) {
                print_error('errorcantupdate', 'scheduler');
            }
        }
    }
}

?>