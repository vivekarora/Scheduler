<?php // $Id: automaticview.php,v 1.2 2009/11/07 10:27:50 diml Exp $

    /**
    * This page prints the screen view for the automatic slots table. 
    * It realizes all "view" related use cases.
    *
    * @package mod-scheduler
    * @category mod
    * @author
    *
    * @usecase add_automaticsession
    * @usecase update_automaticslot
    * other cases delegated to subcontroller
    */

    /*
    * Includes and requires
    */
    include_once($CFG->dirroot.'/mod/scheduler/autolib.php');

    if (!defined('MOODLE_INTERNAL')){
        die('Direct access to this script is forbidden!');
    }

    /**
    *
    */
    $action         = optional_param('action', 'view', PARAM_CLEAN);
    $currentteacher = optional_param('teacher', 0, PARAM_INT);

    $teachernames = array();
    $teachernames[0] = get_string('all');
    if($teachers = get_users_by_capability($context, 'mod/scheduler:attend', 'u.id, firstname, lastname, email, emailstop, picture', 'lastname ASC', '', '', '', '', false, false, false)) {
        foreach($teachers as $teacher) {
            $teachernames[$teacher->id]  = fullname($teacher);
        }
    }

    if ($subaction){
        include($CFG->dirroot.'/mod/scheduler/automaticview.controller.php');
    }

    /************************************ View : Update single slot form ****************************************/
    if ($action == 'update_automaticslot') {
        $slotid = required_param('slotid', PARAM_INT);
    
        print_general_tabs($cm, $scheduler, 'automatic' );
        print_heading(get_string('updatesingleslot', 'scheduler'));
    
        if(empty($subaction)){
            if(!empty($errors)){ // if some errors, get data from client side
                get_automaticslot_data($form);
            } else {
                /// get data from the last inserted
                $slot = $DB->get_record('scheduler_automaticslots', array('id' => $slotid));
                $form = &$slot;
                // get all appointments for this slot
            }
        } elseif($subaction == 'cancel') {
            get_automaticslot_data($form);
            $form->slotid = required_param('slotid', PARAM_INT);
            $form->what = 'doaddupdateslot';
        } elseif($subaction != '') {
            $retcode = include "teacherview.subcontroller.php";
            if ($retcode == -1) return -1;
        }
    
        // print errors and notices
        if (!empty($errors)){
            $errorstr = '';
            foreach($errors as $anError){
                $errorstr .= $anError->message;
            }
            print_simple_box($errorstr, 'center', '70%', '', 5, 'errorbox');
        }
    
        /// print form
        $form->what = 'automatic';
        $form->action = 'doaddupdate_automaticslot';
        $date = getdate($slot->starttime);
        $form->weekday = $date['wday'];
    
        print_simple_box_start('center', '', '');
        include($CFG->dirroot.'/mod/scheduler/oneautomaticslotform.html');
        print_simple_box_end();
        echo '<br />';
    
        // return code for include
        return -1;
    }

    /************************************ Add session multiple slots form ****************************************/
    if ($action == 'add_automaticsession') {
    
        // if there is some error from controller, display it
        if (!empty($errors)){
            $errorstr = '';
            foreach($errors as $anError){
                $errorstr .= $anError->message;
            }
            print_simple_box($errorstr, 'center', '70%', '', 5, 'errorbox');
        }
    
    
        if (!empty($errors)){
            get_session_data($data);
            $form = &$data;
        } else {
            $form->timestart = time();
            $form->timeend = time() + HOURSECS;
            $form->duration = $scheduler->defaultslotduration;
            $form->forcewhenoverlap = 0;
            $form->teacherid = $currentteacher;
            $form->exclusivity = 1;
            $form->duration = $scheduler->defaultslotduration;
            $form->monday = 1;
            $form->tuesday = 1;
            $form->wednesday = 1;
            $form->thursday = 1;
            $form->friday = 1;
            $form->saturday = 0;
            $form->sunday = 0;
        }
    
        print_heading(get_string('addsession', 'scheduler'));
    
        print_simple_box_start('center', '', '');
        include_once($CFG->dirroot.'/mod/scheduler/addautomaticslotsform.html');
        print_simple_box_end();
        echo '<br />';
    
        // return code for include
        return -1;
    }

    //****************** Standard view ***********************************************//


/// print top tabs

    print_general_tabs($cm, $scheduler, 'automatic');

    if(!$scheduler->automaticslots) {
        redirect();
    }
/// print heading

    print_heading($scheduler->name);

/// print page

    print_box(get_string('automaticslotshelp', 'scheduler'));
    $minduration = 0 + @$CFG->scheduler_minperiod;
    if($minduration && $currentteacher) {
        $currentduration = 0;
        $select = " schedulerid = ? AND  teacherid = ? ";
        if($aslots = $DB->get_records_select('scheduler_automaticslots', $select, array($scheduler->id, $currentteacher))) {
            foreach($aslots as $aslot) {
                $currentduration += $aslot->duration;
            }
        }
        $item = new Object();
        $item->min = $minduration * 60;
        $item->current = $currentduration * 60;
        $class = 'generalbox';
        if($currentduration < $minduration) {
            $class = 'error';
        }
        print_box(get_string('automaticdurationhelp', 'scheduler', $item), $class);
        echo '<br />';
    }
    
    if($teachernames) {
        $link = $CFG->wwwroot."/mod/scheduler/view.php?id={$cm->id}&amp;what=automatic&amp;teacher=";
       // popup_form($link, $teachernames, 'teacher', $currentteacher, '');
    }

/// get slots

    $select = " schedulerid = '{$scheduler->id}' ";
    if ($currentteacher) {
        $select .= " AND teacherid = '$currentteacher'";
    }

    $sqlcount = $DB->count_records_select('scheduler_automaticslots', $select, NULL);
    
    if (($offset == '') && ($sqlcount > 25)){
        $offsetcount = $DB->count_records_select('scheduler_slots', $select." AND starttime < '".strtotime('now')."'", NULL);
        $offset = floor($offsetcount/25);
    }
    
    $slots = $DB->get_records_select('scheduler_automaticslots', $select, NULL, 'starttime', '*', $offset * 25, 25);
    
    $straddsession = get_string('addsession', 'scheduler');

/// some slots already exist

    if ($slots){
        // print instructions and button for creating slots
        print_simple_box_start('center', '', '');
        print_string('addslot', 'scheduler');
    
        // print add session button
        $strdeleteallslots = get_string('deleteallslots', 'scheduler');
        $strdeletemyslots = get_string('deletemyslots', 'scheduler');
        $displaydeletebuttons = 1;
        echo '<center>';
        include $CFG->dirroot.'/mod/scheduler/automatic_commands.html';
        echo '</center>';
        print_simple_box_end();
    
    
        $deleteselected= '<script src="'.$CFG->wwwroot.'/mod/scheduler/scripts/listlib.js"></script>
                <form name="deleteslotsform" style="display : inline">
                <input type="hidden" name="id" value="'.$cm->id.'" />
                <input type="hidden" name="what" value="automatic" />
                <input type="hidden" name="action" value="delete_automaticslots" />
                <input type="hidden" name="items" value="" />
                </form>
                <a href="javascript:document.forms[\'deleteslotsform\'].submit()">'.get_string('deleteselection','scheduler').'</a>';
    
        // prepare slots table
        if ($currentteacher){
            $table->head  = array ('', $strdate, $strstart, $strend, $strlocation, $straction);
            $table->align = array ('CENTER', 'LEFT', 'LEFT', 'LEFT', 'CENTER', 'CENTER');
            $table->width = '80%';
        } else {
            $table->head  = array ('', $strdate, $strstart, $strend, $strlocation, format_string($scheduler->staffrolename), $straction);
            $table->align = array ('CENTER', 'LEFT', 'LEFT', 'LEFT', 'CENTER', 'LEFT', 'CENTER' );
            $table->width = '80%';
        }
        $offsetdatemem = '';
        foreach($slots as $slot) {
    
            /// Parameter $local in scheduler_userdate and scheduler_usertime added by power-web.at
            /// When local Time or Date is needed the $local Param must be set to 1
            $offsetdate = userdate($slot->starttime, '%A');
            $offsettime = scheduler_usertime($slot->starttime,1);
            $endtime = scheduler_usertime($slot->starttime + ($slot->duration * 60),1);
            $location = format_string($slot->appointmentlocation);
    
            /// make a slot select box mod/scheduler:deleteall'
            if (($USER->id == $slot->teacherid || has_capability('mod/scheduler:manageallappointments', $context))
                                        && (has_capability('mod/scheduler:deleteall', $context) ) ){
                $selectcheck = "<input type=\"checkbox\" id=\"sel_{$slot->id}\" name=\"sel_{$slot->id}\" onclick=\"document.forms['deleteslotsform'].items.value = toggleListState(document.forms['deleteslotsform'].items.value, 'sel_{$slot->id}', '{$slot->id}');\" />";
            } else {
                $selectcheck = '';
            }
    
    
            $actions = '<span style="font-size: x-small;">';
            if ($USER->id == $slot->teacherid || has_capability('mod/scheduler:manageallappointments', $context)){
                $actions .= "<a href=\"view.php?what=automatic&amp;action=delete_automaticslot&amp;id={$cm->id}&amp;slotid={$slot->id}&amp;page=automatic\"><img src=\"{$CFG->pixpath}/t/delete.gif\" alt=\"".get_string('delete')."\" /></a>";
                $actions .= "&nbsp;<a href=\"view.php?what=automatic&amp;action=update_automaticslot&amp;id={$cm->id}&amp;slotid={$slot->id}&amp;page=automatic\"><img src=\"{$CFG->pixpath}/t/edit.gif\" alt=\"".get_string('move', 'scheduler')."\" /></a>";
    
            }
            $actions .= '</span>';
            if($currentteacher){
                $table->data[] = array ($selectcheck, ($offsetdate == $offsetdatemem) ? '' : $offsetdate, $offsettime, $endtime, $location, $actions);
            } else {
                $teacherlink = "<a href=\"$CFG->wwwroot/user/view.php?id={$slot->teacherid}\">".fullname($DB->get_record('user', array('id' => $slot->teacherid), 'id, firstname, lastname'))."</a>";
                $table->data[] = array ($selectcheck, ($offsetdate == $offsetdatemem) ? '' : $offsetdate, $offsettime, $endtime, $location, $teacherlink, $actions);
            }
            $offsetdatemem = $offsetdate;
        }
    
        // print slots table
        print_heading(get_string('slots' ,'scheduler'));
    
        echo '<div style="width: 80%; margin-left:10%; text-align: center;" >';
    
        if ($sqlcount > 25){
    
            echo get_string('page').': ';
            $pagescount = ceil($sqlcount/25);
            for ($n = 0; $n < $pagescount; $n ++){
                if ($n == $offset){
                    echo ($n+1).' ';
                } else {
                    echo "<a href=view.php?id={$cm->id}&amp;page={$page}&amp;offset={$n}>".($n+1)."</a> ";
                }
            }
            echo '<br />';
        }
        echo '</div><br />';
    
        print_table($table);
    
        echo '<div style="width: 80%; margin-left:10%; text-align: left;" >';
        echo $deleteselected;
        echo '</div>';
    
        echo '<div style="width: 90%; margin-left:5%; text-align: center;" >';
        if ($sqlcount > 25){
            echo get_string('page').': ';
            $pagescount = ceil($sqlcount/25);
            for ($n = 0; $n < $pagescount; $n ++){
                if ($n == $offset){
                    echo ($n+1).' ';
                } else {
                    echo "<a href=view.php?id={$cm->id}&amp;page={$page}&amp;offset={$n}>".($n+1)."</a> ";
                }
            }
            echo '<br />';
        }
    
        echo '</div>';
    
    } else if ($action != 'add_automaticsession') {
        /// There are no slots, should the teacher be asked to make some
        print_simple_box_start('center', '', '');
        print_string('welcomenewteacher', 'scheduler');
        echo '<center>';
        $displaydeletebuttons = 0;
        include($CFG->dirroot.'/mod/scheduler/automatic_commands.html');
        echo '</center>';
        print_simple_box_end();
    }

?>


