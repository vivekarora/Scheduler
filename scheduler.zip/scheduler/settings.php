<?php  //$Id: settings.php,v 1.1 2009/07/29 19:05:39 diml Exp $

require_once($CFG->dirroot.'/mod/scheduler/lib.php');

$settings->add(new admin_setting_configcheckbox('scheduler_allteachersgrading', get_string('allteachersgrading', 'scheduler'),
                   get_string('configallteachersgrading', 'scheduler'), 0));

$options = array(0=>get_string('sunday', 'scheduler'),
                            1=>get_string('monday', 'scheduler'),
                            2=>get_string('tuesday', 'scheduler'),
                            3=>get_string('wednesday', 'scheduler'),
                            4=>get_string('thursday', 'scheduler'),
                            5=>get_string('friday', 'scheduler'),
                            6=>get_string('saturday', 'scheduler'));

$settings->add(new admin_setting_configselect('scheduler_cronwday', get_string('cronwday', 'scheduler'),
                   get_string('configcronwday', 'scheduler'), 0, $options));

$settings->add(new admin_setting_configtime('scheduler_cron_hour', 'scheduler_cron_minute', get_string('executeat'),
                                             get_string('configexecuteatcron', 'scheduler'), array('h' => 3, 'm' => 0)));

$settings->add(new admin_setting_configtext('scheduler_minperiod', get_string('minperiod', 'scheduler'),
                   get_string('configminperiod', 'scheduler'), 360, PARAM_INT));


?>
