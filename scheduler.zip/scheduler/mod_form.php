<?php
require_once ($CFG->dirroot.'/course/moodleform_mod.php');
//define ('MEAN_GRADE', 0); // Used for grading strategy
//define ('MAX_GRADE', 1); // Used for grading strategy

class mod_scheduler_mod_form extends moodleform_mod {

    function definition() {

        global $CFG, $COURSE, $USER;
        $mform    =& $this->_form;


//-------------------------------------------------------------------------------
        $mform->addElement('header', 'general', get_string('general', 'form'));

        $mform->addElement('text', 'name', get_string('name', 'scheduler'), array('size'=>'48'));
        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('name', PARAM_TEXT);
        } else {
            $mform->setType('name', PARAM_CLEAN);
        }
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');

        $mform->addElement('htmleditor', 'description', get_string('description'));
        $mform->setType('description', PARAM_RAW);
        $mform->addRule('description', get_string('required'), 'required', null, 'client');
        $mform->setHelpButton('description', array('writing', 'questions', 'richtext2'), false, 'editorhelpbutton');

        $mform->addElement('text', 'staffrolename', get_string('staffrolename', 'scheduler'), array('size'=>'36'));
        $mform->setDefault('staffrolename', get_string('staffhost', 'scheduler'));
        $mform->setHelpButton('staffrolename', array('staffrolename', get_string('staffrolename', 'scheduler'), 'scheduler'));

        $options = array();
        $options['onetime'] = get_string('oneatatime', 'scheduler');
        $options['oneonly'] = get_string('oneappointmentonly', 'scheduler') ;
        $mform->addElement('select', 'schedulermode', get_string('mode', 'scheduler'), $options);
        $mform->setHelpButton('schedulermode', array('appointmentmode', get_string('mode', 'scheduler'), 'scheduler'));

        $options = array();
        $options['8'] = ' 8 '.get_string('hours');
        $options['12'] = '12 '.get_string('hours');
        $options['18'] = '18 '.get_string('hours');
        $options['24'] = '1 '.get_string('day');
        $options['36'] = '1,5 '.get_string('days');
        $options['48'] = '2 '.get_string('days');
        $options['72'] = '3 '.get_string('days');
        $options['96'] = '4 '.get_string('days');
        $options['168'] = '1 '.get_string('week');
        $options['336'] = '2 '.get_string('week');
        $mform->addElement('select', 'reuseguardtime', get_string('reuseguardtime', 'scheduler'), $options);
        $mform->setHelpButton('reuseguardtime', array('reuseguardtime', get_string('reuseguardtime', 'scheduler'), 'scheduler'));
        $mform->setDefault('reuseguardtime', '18');


        $mform->addElement('text', 'defaultslotduration', get_string('defaultslotduration', 'scheduler'), array('size'=>'4'));
        $mform->setType('defaultslotduration', PARAM_INT);
        $mform->setDefault('defaultslotduration', '60');
        $mform->addRule('defaultslotduration', null, 'numeric', null, 'client');
        $mform->setHelpButton('defaultslotduration', array('defaultslotduration', get_string('defaultslotduration', 'scheduler'),'scheduler'));

        $mform->addElement('selectyesno', 'allownotifications', get_string('notifications', 'scheduler'));
        $mform->setHelpButton('allownotifications', array('allownotifications', get_string('notifications', 'scheduler'),'scheduler'));
        $mform->setDefault('allownotifications', 0);

        $options = array();
        $options['0'] = get_string('forceonlysingle', 'scheduler');
        $options['1'] = get_string('forceno', 'scheduler');
        $options['2'] = get_string('forceonlygroups', 'scheduler');
        $mform->addElement('select', 'forcegroupappoint', get_string('forcegroupappoint', 'scheduler'), $options);
        $mform->setHelpButton('forcegroupappoint', array('forcegroupappoint', get_string('forcegroupappoint', 'scheduler'),'scheduler'));
        $mform->setDefault('forcegroupappoint', 0);
        $mform->disabledIf('forcegroupappoint', 'groupmode', 'eq', NOGROUPS);

        $options = array();
        $options['0'] = get_string('no');
        $options['1'] = get_string('automaticfree', 'scheduler') ;
        $options['2'] = get_string('automaticforce', 'scheduler') ;
        $mform->addElement('select', 'automaticslots', get_string('automaticslots', 'scheduler'), $options);
        $mform->setHelpButton('automaticslots', array('automaticslots', get_string('automaticslots', 'scheduler'),'scheduler'));
        $mform->setDefault('automaticslots', 0);


//-------------------------------------------------------------------------------
        $mform->addElement('header', '', get_string('grade'));

        $gradeaggregates = array();
        $gradeaggregates[NO_GRADE] = get_string('nograde', 'scheduler');
        $gradeaggregates[MEAN_GRADE] = get_string('meangrade', 'scheduler') ;
        $gradeaggregates[MAX_GRADE] = get_string('maxgrade', 'scheduler');
        $mform->addElement('select', 'gradingstrategy', get_string('gradingstrategy', 'scheduler') , $gradeaggregates);
        $mform->setDefault('gradingstrategy', NO_GRADE);
        $mform->setHelpButton('gradingstrategy', array('gradingstrategy', get_string('gradingstrategy', 'scheduler'), 'scheduler'));

        $mform->addElement('modgrade', 'scale', get_string('grade'), false);
        $mform->disabledIf('scale', 'gradingstrategy', 'eq', NO_GRADE);

//-------------------------------------------------------------------------------
        $features = new stdClass;
        $features->groups = true;
        $features->groupings = true;
        $features->groupmembersonly = true;
        $this->standard_coursemodule_elements($features);
//-------------------------------------------------------------------------------
// buttons
        $this->add_action_buttons();

    }

    function data_preprocessing(&$default_values){
        if (empty($default_values['scale'])){
            $default_values['scale'] = 0;
        }
    }

}
?>
