<?php

if (!defined('MOODLE_INTERNAL')){
    die('Direct access to this script is forbidden!');
}

/**
* Returns an array of slots that would overlap with this one.
* @param int $schedulerid the current activity module id
* @param int $starttimethe start of time slot as a timestamp
* @param int $endtime end of time slot as a timestamp
* @param int $teacher if not null, the id of the teacher constraint, 0 otherwise standas for "all teachers"
* @param int $others selects where to search for conflicts, [SCHEDULER_SELF, SCHEDULER_OTHERS, SCHEDULER_ALL]
* @param boolean $careexclusive if false, conflict will consider all slots wether exlusive or not. Use it for testing if user is appointed in the given scope.
* @uses $CFG
* @uses $DB
* @return array array of conflicting slots
*/
function scheduler_automatic_get_conflicts($schedulerid, $starttime, $endtime, $teacher=0, $others=SCHEDULER_SELF, $careexclusive=true) {
    global $CFG, $DB;

    switch ($others){
        case SCHEDULER_SELF:
            $schedulerScope = " schedulerid = '{$schedulerid}' AND ";
            break;
        case SCHEDULER_OTHERS:
            $schedulerScope = " schedulerid != '{$schedulerid}' AND ";
            break;
        default:
            $schedulerScope = '';
    }
    $teacherScope = ($teacher != 0) ? " teacherid = '{$teacher}' AND " : '' ;
    $exclusiveClause = ($careexclusive) ? " exclusivity != 0 AND " : '' ;
    $sql = "
        SELECT 
            *
        FROM
            {scheduler_automaticslots}
        WHERE
            {$schedulerScope}
            {$teacherScope}
            {$exclusiveClause}
            ( (starttime <= {$starttime} AND
            starttime + duration * 60 > {$starttime}) OR
            (starttime < {$endtime} AND
            starttime + duration * 60 >= {$endtime}) OR
            (starttime >= {$starttime} AND
            starttime + duration * 60 <= {$endtime}) )
    ";
    $conflicting = $DB->get_records_sql($sql, NULL);

    return $conflicting;
}

/**
*
*/
function get_automaticslot_data(&$form){
    $start = strtotime('next Sunday', 0);
    $date = getdate($start);

    $form->teacherid    = required_param('teacherid', PARAM_INT);
    $form->exclusivity  = required_param('exclusivity', PARAM_INT);
    $form->divide       = optional_param('divide', 0, PARAM_INT);
    $form->duration     = optional_param('duration', 15, PARAM_INT);
    $form->appointmentlocation = optional_param('appointmentlocation', '', PARAM_TEXT);

    $form->weekday      = required_param('weekday', PARAM_INT);
    $form->hour         = required_param('hour', PARAM_INT);
    $form->minute       = required_param('minute', PARAM_INT);
    $form->starttime    = make_timestamp($date['year'], $date['mon'], $date['mday']+$form->weekday,  $form->hour, $form->minute);

}

/**
*
*/
function get_automaticsession_data(&$form){
    $start = strtotime('next Sunday', 0);
    $date = usergetdate($start);

    $form->teacherid    = required_param('teacherid', PARAM_INT);
    $form->exclusivity  = required_param('exclusivity', PARAM_INT);
    $form->divide       = optional_param('divide', 0, PARAM_INT);
    $form->duration     = optional_param('duration', 15, PARAM_INT);
    $form->appointmentlocation = optional_param('appointmentlocation', '', PARAM_TEXT);
    $form->starthour    = required_param('starthour', PARAM_RAW);
    $form->startminute  = optional_param('startminute', PARAM_RAW);
    $form->endhour      = required_param('endhour', PARAM_RAW);
    $form->endminute    = optional_param('endminute', PARAM_RAW);

    $form->rangestart   = make_timestamp($date['year'], $date['mon'], $date['mday']);
    $form->timestart    = make_timestamp($date['year'], $date['mon'], $date['mday'], $form->starthour, $form->startminute);
    $form->timeend      = make_timestamp($date['year'], $date['mon'], $date['mday']+7, $form->endhour, $form->endminute);

    $form->monday       = optional_param('monday', 0, PARAM_INT);
    $form->tuesday      = optional_param('tuesday', 0, PARAM_INT);
    $form->wednesday    = optional_param('wednesday', 0, PARAM_INT);
    $form->thursday     = optional_param('thursday', 0, PARAM_INT);
    $form->friday       = optional_param('friday', 0, PARAM_INT);
    $form->saturday     = optional_param('saturday', 0, PARAM_INT);
    $form->sunday       = optional_param('sunday', 0, PARAM_INT);
    $form->forcewhenoverlap = required_param('forcewhenoverlap', PARAM_INT);
}

?>