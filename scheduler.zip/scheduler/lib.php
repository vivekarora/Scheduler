<?PHP  // $Id: lib.php,v 1.20 2009/11/06 17:54:43 diml Exp $

/**
* @package mod-scheduler
* @category mod
* @author Gustav Delius, Valery Fremaux > 1.8
* @version 2.0
*
*/

include_once($CFG->dirroot.'/mod/scheduler/locallib.php');

/// Library of functions and constants for module scheduler

define('SCHEDULER_TIMEUNKNOWN', 0);  // This is used for appointments for which no time is entered
define('SCHEDULER_SELF', 0); // Used for setting conflict search scope
define('SCHEDULER_OTHERS', 1); // Used for setting conflict search scope
define('SCHEDULER_ALL', 2); // Used for setting conflict search scope

define ('NO_GRADE', 0); // Used for grading strategy
define ('MEAN_GRADE', 1); // Used for grading strategy
define ('MAX_GRADE', 2); // Used for grading strategy

/**
* Given an object containing all the necessary data,
* will create a new instance and return the id number
* of the new instance.
* @param object $scheduler the current instance
* @return int the new instance id
* @uses $DB
*/
function scheduler_add_instance($scheduler) {
    global $DB;
    
    $scheduler->timemodified = time();
    $id = $DB->insert_record('scheduler', $scheduler);
    return $id;
}

/**
* Given an object containing all the necessary data,
* (defined by the form in mod.html) this function
* will update an existing instance with new data.
* @param object $scheduler the current instance
* @return object the updated instance
* @uses $DB
*/
function scheduler_update_instance($scheduler) {
    global $DB;
    
    $scheduler->timemodified = time();
    $scheduler->id = $scheduler->instance;

    return $DB->update_record('scheduler', $scheduler);
}


/**
* Given an ID of an instance of this module,
* this function will permanently delete the instance
* and any data that depends on it.
* @param int $id the instance to be deleted
* @return boolean true if success, false otherwise
* @uses $DB
*/
function scheduler_delete_instance($id) {
    global $CFG, $DB;

    if (! $scheduler = $DB->get_record('scheduler', array('id' => $id))) {
        return false;
    }

    $result = true;

    if (! $DB->delete_records('scheduler', array('id' => $scheduler->id))) {
        $result = false;
    }

    $oldslots = $DB->get_records('scheduler_slots', array('schedulerid' => $scheduler->id), '', 'id, id');
    if ($oldslots){
        foreach(array_keys($oldslots) as $slotid){
            // will delete appointements and remaining related events
            scheduler_delete_slot($slotid);
        }
    }

    return $result;
}

/**
* Return a small object with summary information about what a
* user has done with a given particular instance of this module
* Used for user activity reports.
* $return->time = the time they did it
* $return->info = a short text description
* @param object $course the course instance
* @param object $user the concerned user instance
* @param object $mod the current course module instance
* @param object $scheduler the activity module behind the course module instance
* @return object an information object as defined above
*/
function scheduler_user_outline($course, $user, $mod, $scheduler) {
    $return = NULL;
    return $return;
}

/**
* Prints a detailed representation of what a  user has done with
* a given particular instance of this module, for user activity reports.
* @param object $course the course instance
* @param object $user the concerned user instance
* @param object $mod the current course module instance
* @param object $scheduler the activity module behind the course module instance
* @param boolean true if the user completed activity, false otherwise
*/
function scheduler_user_complete($course, $user, $mod, $scheduler) {

    return true;
}

/**
* Given a course and a time, this module should find recent activity
* that has occurred in scheduler activities and print it out.
* Return true if there was output, or false is there was none.
* @param object $course the course instance
* @param boolean $isteacher true tells a teacher uses the function
* @param int $timestart a time start timestamp
* @return boolean true if anything was printed, otherwise false
*/
function scheduler_print_recent_activity($course, $isteacher, $timestart) {

    return false;
}

/**
* Function to be run periodically according to the moodle
* This function searches for things that need to be done, such
* as sending out mail, toggling flags etc ...
* @return boolean always true
* @uses $CFG
* @uses $DB
*/
function scheduler_cron () {
    global $CFG, $DB;

    $date = make_timestamp(date('Y'), date('m'), date('d'), date('H'), date('i'));

    // for every appointment in all schedulers
    $select = "
        emaildate > 0 AND
        emaildate <= ?
    ";
    $slots = $DB->get_records_select('scheduler_slots', $select, array($date), 'starttime');

    if ($slots){
          foreach ($slots as $slot) {
            // get teacher
            $teacher = $DB->get_record('user', array('id' => $slot->teacherid));

            // get appointed student list
            $appointments = $DB->get_records('scheduler_appointment', array('slotid', $slot->id), '', 'id, studentid');

            //if no email previously sent and one is required
            if ($appointments){
                foreach($appointments as $appointed){
                    $recipient = $DB->get_record('user', array('id' => $appointed->studentid));
                    if(email_to_user($recipient, $teacher, get_string('remindwithwhom', 'scheduler').fullname($teacher),get_string('remindwithwhom', 'scheduler').fullname($teacher).' '.get_string('on', 'scheduler').' '.date("l jS F Y",$slot->starttime).' '.get_string('from').' '.date("H:i",$slot->starttime).' '.get_string('to').' '.date("H:i",$slot->starttime + $slot->duration).'. '.get_string('remindwhere', 'scheduler').$slot->location.".")){
                    }
                }
            }
            $slot->emaildate  = -1;
            $DB->update_record('scheduler_slots', $slot);
        }
    }

    // ULPGC ecastro deleting past unused slots
    $old = strtotime(" -1 week");  //
    $rs_schedulers = $DB->get_recordset_select('scheduler', " id > 0 ", NULL, 'id, name');
    foreach($rs_schedulers as $scheduler) {
        scheduler_free_late_unused_slots($scheduler->id, $old);
    }
    $rs_schedulers->close();

    /// process automatic slots
    $wdays = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
    $day = $wdays[$CFG->scheduler_cronwday];
    if(! $DB->record_exists('config', array('name' => 'scheduler_lastcron'))) {
        $lastcron = new Object();
        $lastcron->name = 'scheduler_lastcron';
        $lastcron->value = '0';
        $DB->insert_record('config', $lastcron);
        unset($lastcron);
        $CFG->scheduler_lastcron = 0;
    }
    $now = time();
        //$now = usertime(strtotime("5 October 2008 6 hours"));
    $date = usergetdate($now);

    if($date['wday'] !== $CFG->scheduler_cronwday) {
        $weekstart = strtotime("next $day ", $now);
        $date = usergetdate($weekstart);
    }

    $weekstart =  make_timestamp($date['year'], $date['mon'], $date['mday']);

    $timetocheck = $weekstart + $CFG->scheduler_cron_hour*60*60 + $CFG->scheduler_cron_minute*60;

    if($timetocheck<$now && $CFG->scheduler_lastcron<$now) {
        //now we can proceed
        $starttime = strtotime("+1 week ", $weekstart);
        $endtime = strtotime("+1 week ", $starttime); // a period of a week
        $minduration = $CFG->scheduler_minperiod;
        scheduler_cron_automatic_slots($starttime, $endtime, $minduration);
    }

    return true;
}

/**
* Must return an array of grades for a given instance of this module,
* indexed by user. It also returns a maximum allowed grade.
* @param int $schedulerid the id of the activity module
* @return array an array of grades
* @uses $CFG
* @uses $DB
*/
function scheduler_grades($cmid) {
    global $CFG, $DB;

    if (!$module = $DB->get_record('course_modules', array('id' => $cmid))){
        return NULL;
    }

    if (!$scheduler = $DB->get_record('scheduler', array('id' => $module->instance))){
        return NULL;
    }

    if ($scheduler->scale == 0) { // No grading
        return NULL;
    }

    $sql = '
       SELECT
          a.id,
          a.studentid,
          a.grade
       FROM
          {scheduler_slots} s
       LEFT JOIN
          {scheduler_appointment} a
       ON
          s.id = a.slotid
       WHERE
          s.schedulerid = ? AND
          a.grade IS NOT NULL
    ';
    // echo $sql ;
    $grades = $DB->get_records_sql($sql, array($scheduler->id));
    if ($grades){
        if ($scheduler->scale > 0 ){ // Grading numerically
            $finalgrades = array();
            foreach($grades as $aGrade){
                $finals[$aGrade->studentid]->sum = @$finals[$aGrade->studentid]->sum + $aGrade->grade;
                $finals[$aGrade->studentid]->count = @$finals[$aGrade->studentid]->count + 1;
                $finals[$aGrade->studentid]->max = (@$finals[$aGrade->studentid]->max < $aGrade->grade) ? $aGrade->grade : @$finalgrades[$aGrade->studentid]->max ;
            }

            /// compute the adequate strategy
            foreach($finals as $student => $aGradeSet){
                switch ($scheduler->gradingstrategy){
                    case NO_GRADE:
                        $finalgrades[$student] = '';
                        break;
                    case MAX_GRADE:
                        $finalgrades[$student] = $aGradeSet->max;
                        break;
                    case MEAN_GRADE:
                        $finalgrades[$student] = $aGradeSet->sum / $aGradeSet->count ;
                        break;
                }
            }

            $return->grades = $finalgrades;
            $return->maxgrade = $scheduler->scale;
        }
        else { // Scales
            $finalgrades = array();
            $scaleid = - ($scheduler->scale);
            $maxgrade = '';
            if ($scale = $DB->get_record('scale', array('id' => $scaleid))) {
                $scalegrades = make_menu_from_list($scale->scale);
                foreach ($grades as $aGrade) {
                    $finals[$aGrade->studentid]->sum = @$finals[$aGrade->studentid]->sum + $scalegrades[$aGgrade->grade];
                    $finals[$aGrade->studentid]->count = @$finals[$aGrade->studentid]->count + 1;
                    $finals[$aGrade->studentid]->max = (@$finals[$aGrade->studentid]->max < $aGrade) ? $scalegrades[$aGgrade->grade] : @$finals[$aGrade->studentid]->max ;
                }
                $maxgrade = $scale->name;
            }

            /// compute the adequate strategy
            foreach($finals as $student => $aGradeSet){
                switch ($scheduler->gradingstrategy){
                    case NO_GRADE:
                        $finalgrades[$student] = '';
                        break;
                    case MAX_GRADE:
                        $finalgrades[$student] = $aGradeSet->max;
                        break;
                    case MEAN_GRADE:
                        $finalgrades[$student] = $aGradeSet->sum / $aGradeSet->count ;
                        break;
                }
            }

            $return->grades = $finalgrades;
            $return->maxgrade = $maxgrade;
        }
        return $return;
    }
    return NULL;
}

/**
* Returns the users with data in one scheduler
* (users with records in journal_entries, students and teachers)
* @param int $schedulerid the id of the activity module
* @uses $CFG
* @uses $DB
*/
function scheduler_get_participants($schedulerid) {
    global $CFG, $DB;

    //Get students using slots they have
    $sql = '
        SELECT DISTINCT
            u.*
        FROM
            {user} u,
            {scheduler_slots} s,
            {scheduler_appointment} a
        WHERE
            s.schedulerid = ? AND
            s.id = a.slotid AND
            u.id = a.studentid
    ';
    $students = $DB->get_records_sql($sql, array($schedulerid));

    //Get teachers using slots they have
    $sql = '
        SELECT DISTINCT
            u.*
        FROM
            {user} u,
            {scheduler_slots} s
        WHERE
            s.schedulerid = ? AND
            u.id = s.teacherid
    ';
    $teachers = $DB->get_records_sql($sql, array($schedulerid));

    if ($students and $teachers){
        $participants = array_merge(array_values($students), array_values($teachers));
    }
    elseif ($students) {
        $participants = array_values($students);
    }
    elseif ($teachers){
        $participants = array_values($teachers);
    }
    else{
      $participants = array();
    }

    //Return students array (it contains an array of unique users)
    return ($participants);
}

/**
 * This function returns if a scale is being used by one newmodule
 * it it has support for grading and scales. Commented code should be
 * modified if necessary. See forum, glossary or journal modules
 * as reference.
 *
 * @param int $newmoduleid ID of an instance of this module
 * @return mixed
 * @uses $DB
 **/
function scheduler_scale_used($cmid, $scaleid) {
    global $DB;
    
    $return = false;

    // note : scales are assigned using negative index in the grade field of the appointment (see mod/assignement/lib.php)
    $rec = $DB->get_record('scheduler', array('id' => $cmid, 'scale' => -$scaleid));

    if (!empty($rec) && !empty($scaleid)) {
        $return = true;
    }

    return $return;
}


/**
 * Checks if scale is being used by any instance of scheduler
 *
 * This is used to find out if scale used anywhere
 * @param $scaleid int
 * @return boolean True if the scale is used by any scheduler
 * @uses $DB
 */
function scheduler_scale_used_anywhere($scaleid) {
    global $DB;
    
    if ($scaleid and $DB->record_exists('scheduler', array('scale' => -$scaleid))) {
        return true;
    } else {
        return false;
    }
}


/**
 * Course resetting API
 * Called by course/reset.php
 */
function scheduler_reset_course_form($course) {
    echo get_string('resetschedulers', 'scheduler'); 
    echo ':<br />';
    print_checkbox('reset_appointments', 1, true, get_string('appointments','scheduler'), '', '');  
    echo '<br />';
    print_checkbox('reset_slots', 1, true, get_string('slots','scheduler'), '', '');  
    echo '<br />';
    echo '</p>';
}

/**
* This function is used by the remove_course_userdata function in moodlelib.
* If this function exists, remove_course_userdata will execute it.
* This function will remove all posts from the specified forum.
* @param data the reset options
* @return void
* @uses $CFG
* @uses $DB
*/
function scheduler_delete_userdata($data, $showfeedback = true) {
    global $CFG, $DB;

    $sql_appointments = "
        DELETE FROM
            {scheduler_appointment} a
        WHERE
            slotid
        IN ( SELECT
                s.id
             FROM
                {scheduler_slots} s,
                {scheduler} AS sc
             WHERE
                sc.id = s.schedulerid AND
                sc.course = {$data->courseid}
        )
    ";

    $sql_slots = "
        DELETE FROM
            {$CFG->prefix}scheduler_slots
        WHERE
            slotid
        IN ( SELECT
                s.id
             FROM
                {$CFG->prefix}scheduler AS sc
             WHERE
                sc.course = {$data->courseid}
        )
    ";

    $strreset = get_string('reset');

    if (!empty($data->reset_appointments) || !empty($data->reset_slots)) {
        if ($DB->execute_sql($sql_appointments, false) and $showfeedback) {
            notify($strreset.': '.get_string('appointments','scheduler'), 'notifysuccess');
        }
    }
    if (!empty($data->reset_slots)) {
        if ($DB->execute_sql($sql_slots, false) and $showfeedback) {
            notify($strreset.': '.get_string('slots','scheduler'), 'notifysuccess');
        }
    }
}

?>
