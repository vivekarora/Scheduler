<?php

/**
* @package mod-scheduler
* @category mod
* @author
*
* This is a controller for major automatic side use cases
*
* @usecase doaddupdate_automaticslot
* @usecase doadd_automaticsession
* @usecase deleteall_automatic
* @usecase delete_automaticslot
*/

if (!defined('MOODLE_INTERNAL')){
    die('Direct access to this script is forbidden!');
}

$currentteacher = optional_param('teacher', 0, PARAM_INT);

// We first have to check whether some action needs to be performed
switch ($subaction) {

/************************************ creates or updates a slot ***********************************************/
/*
* If fails, should reenter within the form signalling error cause
*/
    case 'doaddupdate_automaticslot':{
        // get expected parameters
        $slotid = optional_param('slotid', '', PARAM_INT);

        // get standard slot parms
        get_automaticslot_data($data);

        $errors = array();

        if ($data->teacherid == 0){
            unset($erroritem);
            $erroritem->message = get_string('noteacherforslot', 'scheduler');
            $erroritem->on = 'teacherid';
            $errors[] = $erroritem;
        }

        if (count($errors)){
            $action = 'addslot';
            return;
        }

        // Avoid overlapping slots, by asking the user if they'd like to overwrite the existing ones...
        // for other scheduler, we check independently of exclusivity. Any slot here conflicts
        // for this scheduler, we check against exclusivity. Any complete slot here conflicts
        $conflictsRemote = scheduler_automatic_get_conflicts($scheduler->id, $data->starttime, $data->starttime + $data->duration * 60, $data->teacherid, 0, SCHEDULER_OTHERS, false);
        $conflictsLocal = scheduler_automatic_get_conflicts($scheduler->id, $data->starttime, $data->starttime + $data->duration * 60, $data->teacherid, 0, SCHEDULER_SELF);
        if (!$conflictsRemote) $conflictsRemote = array();
        if (!$conflictsLocal) $conflictsLocal = array();
        $conflicts = $conflictsRemote + $conflictsLocal;

        // remove itself from conflicts when updating
        if (!empty($slotid) and array_key_exists($slotid, $conflicts)){
            unset($conflicts[$slotid]);
        }

        if (count($conflicts)) {
            if ($subaction == 'confirmdelete' && confirm_sesskey()) {
                foreach ($conflicts as $conflict) {
                    if ($conflict->id != @$slotid) {
                        delete_records('scheduler_automaticslots', array('id' => $conflict->id));
                    }
                }
            }
            else {
                echo "<br/><br/>";
                print_simple_box_start('center', '', '');
                    echo get_string('slotwarning', 'scheduler').'<br/><br/>';
                    $options = array();
                    $options['what'] = 'automatic';
                    $options['action'] = 'add_automaticslot';
                    $options['id'] = $cm->id;
                    $options['page'] = $page;
                    $options['slotid'] = $slotid;
                    print_single_button('view.php', $options, get_string('cancel'));

                    $options['what'] = 'automatic';
                    $options['action'] = 'doaddupdate_automaticslot';
                    $options['subaction'] = 'confirmdelete';
                    $options['sesskey'] = sesskey();
                    $options['hour'] = $data->hour;
                    $options['minute'] = $data->minute;
                    $options['duration'] = $data->duration;
                    $options['teacherid'] = $data->teacherid;
                    $options['exclusivity'] = $data->exclusivity;
                    $options['appointmentlocation'] = $data->appointmentlocation;
                    print_single_button('view.php', $options, get_string('deletetheseslots', 'scheduler'));
                print_simple_box_end();
                print_footer($course);
                die();
            }
        }

        // make new slot record
        $slot->schedulerid = $scheduler->id;
        $slot->starttime = $data->starttime;
        $slot->duration = $data->duration;
        $slot->exclusivity = $data->exclusivity;
        $slot->timemodified = time();
        if(!empty($data->teacherid)) {
            $slot->teacherid = $data->teacherid;
        }
        $slot->appointmentlocation = $data->appointmentlocation;
        if (!$slotid){ // add it
            if (!($slot->id = $DB->insert_record('scheduler_automaticslots', $slot))) {
                print_error('errorcantinsert', get_string('slot', 'scheduler'));
            }
            print_heading(get_string('oneslotadded','scheduler'));
        }
        else{ // update it
            $slot->id = $slotid;
            if (!($DB->update_record('scheduler_automaticslots', $slot))) {
                print_error('errorcantupdate', get_string('slot', 'scheduler'));
            }
            print_heading(get_string('slotupdated','scheduler'));
        }
        break;
    }
/************************************ Saving a session with slots *************************************/
    case 'doadd_automaticsession':{
        // This creates sessions using the data submitted by the user via the form on add.html
        get_automaticsession_data($data);

        $fordays = 7;

        $errors = array();

        if ($data->teacherid == 0){
            unset($erroritem);
            $erroritem->message = get_string('noteacherforslot', 'scheduler');
            $erroritem->on = 'teacherid';
            $errors[] = $erroritem;
        }

        // first error trap. Ask to correct that first
        if (count($errors)){
            $action = 'addsession';
            break;
        }

        /// make a base slot for generating
        $slot->appointmentlocation = $data->appointmentlocation;
        $slot->exclusivity = $data->exclusivity;
        $slot->duration = $data->duration;
        $slot->schedulerid = $scheduler->id;
        $slot->timemodified = time();
        $slot->teacherid = $data->teacherid;

        /// check if overlaps. Check also if some slots are in allowed day range
        $startfrom = $data->rangestart;
        $noslotsallowed = true;
        for ($d = 0; $d <= $fordays; $d ++){
            //$eventdate = usergetdate($startfrom + ($d * 86400));
            $dayofweek = date('l', $startfrom + ($d * 86400));
            if ((($dayofweek == 'Monday') && ($data->monday == 1)) ||
                (($dayofweek == 'Tuesday') && ($data->tuesday == 1)) ||
                (($dayofweek == 'Wednesday') && ($data->wednesday == 1)) ||
                (($dayofweek == 'Thursday') && ($data->thursday == 1)) ||
                (($dayofweek == 'Friday') && ($data->friday == 1)) ||
                (($dayofweek == 'Saturday') && ($data->saturday == 1)) ||
                (($dayofweek == 'Sunday') && ($data->sunday == 1))){
                $noslotsallowed = false;
                $data->starttime = $startfrom + ($d * 86400);
                $conflicts = scheduler_automatic_get_conflicts($scheduler->id, $data->starttime, $data->starttime + $data->duration * 60, $data->teacherid);
                if (!$data->forcewhenoverlap){
                    if ($conflicts){
                        unset($erroritem);
                        $erroritem->message = get_string('overlappings', 'scheduler');
                        $erroritem->on = 'range';
                        $errors[] = $erroritem;
                    }
                }
            }
        }

        /// Finally check if some slots are allowed (an error is thrown to ask care to this situation)
        if ($noslotsallowed){
            unset($erroritem);
            $erroritem->message = get_string('allslotsincloseddays', 'scheduler');
            $erroritem->on = 'days';
            $errors[] = $erroritem;
        }

        // second error trap. For last error cases.
        if (count($errors)){
            $action = 'add_automaticsession';
            break;
        }

        /// Now create as many slots of $duration as will fit between $starttime and $endtime and that do not conflicts
        $countslots = 0;
        $couldnotcreateslots = '';
        $startfrom = $data->timestart;
        for ($d = 0; $d <= $fordays; $d ++){
            $eventdate = usergetdate($startfrom + ($d * DAYSECS));
            $dayofweek = date('l', $startfrom + ($d * DAYSECS));
            if ((($dayofweek == 'Monday') && ($data->monday == 1)) ||
                (($dayofweek == 'Tuesday') && ($data->tuesday == 1)) ||
                (($dayofweek == 'Wednesday') && ($data->wednesday == 1)) ||
                (($dayofweek == 'Thursday') && ($data->thursday == 1)) ||
                (($dayofweek == 'Friday') && ($data->friday == 1)) ||
                (($dayofweek == 'Saturday') && ($data->saturday == 1)) ||
                (($dayofweek == 'Sunday') && ($data->sunday == 1))){
                $slot->starttime = $startfrom + ($d * DAYSECS);
                $data->timestart = $startfrom + ($d * DAYSECS);
                $data->timeend = make_timestamp(date('Y',$data->timestart), date('m',$data->timestart), date('d',$data->timestart), $data->endhour, $data->endminute);

                // this corrects around midnight bug
                if ($data->timestart > $data->timeend){
                    $data->timeend += DAYSECS;
                }
                $conflicting = 0;
                $deleted = 0;
                while ($slot->starttime <= $data->timeend - $data->duration * 60) {
                    $conflicts = scheduler_automatic_get_conflicts($scheduler->id, $data->timestart, $data->timestart + $data->duration * 60, $data->teacherid);
                    if ($conflicts) {
                        if (!$data->forcewhenoverlap){
                            //print_string('conflictingslots', 'scheduler');
                            //echo '<ul>';
                            foreach ($conflicts as $aConflict){
                                $conflicting ++;
                                $sql = "
                                   SELECT
                                      c.fullname,
                                      c.shortname,
                                      sl.starttime
                                   FROM
                                      {course} c,
                                      {scheduler} s,
                                      {scheduler_automaticslots} sl
                                   WHERE
                                      s.course = c.id AND
                                      sl.schedulerid = s.id AND
                                      sl.id = {$aConflict->id}
                                ";
                                //$conflictinfo = get_record_sql($sql);
                                //echo '<li> ' . userdate($conflictinfo->starttime) . ' ' . usertime($conflictinfo->starttime) . ' ' . get_string('incourse', 'scheduler') . ': ' . $conflictinfo->shortname . ' - ' . $conflictinfo->fullname . "</li>\n";
                            }
                            //echo '</ul><br/>';
                        } else { // we force, so delete all conflicting before inserting
                            foreach($conflicts as $conflict){
                                scheduler_delete_slot($conflict->id);
                                $deleted ++;
                            }
                        }
                    } else {
                        if (!$DB->insert_record('scheduler_automaticslots', $slot, false)) {
                            print_error('errorcantinsert', get_string('slot', 'scheduler'));
                        }
                        $countslots++;
                    }
                    $slot->starttime += $data->duration * 60;
                    $data->timestart += $data->duration * 60;
                }
            }
        }
        print_heading($countslots.get_string('slotsadded', 'scheduler'));
        if($conflicting) {
            notify(get_string('conflictingslots', 'scheduler', $conflicting));
        }
        if($deleted) {
            notify(get_string('conflictingslotsdel', 'scheduler', $deleted));
        }
        break;
    }
/************************************ Deleting a slot ***********************************************/
    case 'delete_automaticslot': {
        $slotid = required_param('slotid', PARAM_INT);
        require_capability('mod/scheduler:deleteunused', $context, $USER->id);
        delete_records('scheduler_automaticslots', array('id' => $slotid));
        break;
    }
/************************************ Deleting multiple slots ***********************************************/
    case 'delete_automaticslots': {
        $slotids = required_param('items', PARAM_RAW);
        require_capability('mod/scheduler:deleteallunused', $context, $USER->id);
        $slots = explode(",", $slotids);
        foreach($slots as $aslotid){
            delete_records('scheduler_automaticslots', array('id' => $aslotid));
        }
        break;
    }
/************************************ Deleting all slots ***************************************************/
    case 'deleteall_automaticslots':{
        require_capability('mod/scheduler:deleteall', $context, $USER->id);
        delete_records('scheduler_automaticslots', array('schedulerid' => $cm->instance));
        break;
    }
/************************************ Deleting my slots *************************************************/
    case 'delete_myautomaticslots':{
       require_capability('mod/scheduler:deleteunused', $context, $USER->id);
       $select = ' schedulerid = ? AND teacherid = ? ';
       delete_records_select('scheduler_automaticslots', $select, array($scheduler->id, $currentteacher));
    }
    break;
/************************************ Toggling to unlimited group ***************************************/
    case 'allowgroup':{
        $slotid = required_param('slotid', PARAM_INT);
        unset($slot);
        $slot->id = $slotid;
        $slot->exclusivity = 0;
        $DB->update_record('scheduler_slots', $slot);
        break;
    }

/************************************ Toggling to single student ******************************************/
    case 'forbidgroup':{
        $slotid = required_param('slotid', PARAM_INT);
        unset($slot);
        $slot->id = $slotid;
        $slot->exclusivity = 1;
        $DB->update_record('scheduler_slots', $slot);
        break;
    }
}

?>