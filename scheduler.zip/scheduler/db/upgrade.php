<?php

function xmldb_scheduler_upgrade($oldversion=0) {
/// This function does anything necessary to upgrade
/// older versions to match current functionality

    global $CFG;

    //****** Moodle 2.0 Barrier **********/

    $result = true;

    return $result;
}

?>
