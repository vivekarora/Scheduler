<?php

/**
* @package mod-scheduler
* @category mod
* @author Gustav Delius, Valery Fremaux > 1.8
*
*/

/**
* Parameter $local added by power-web.at
* When local Date is needed the $local Param must be set to 1
* @param int $date a timestamp
* @param int $local
* @todo check consistence
* @return string printable date
*/
function scheduler_userdate($date, $local=0) {
    if ($date == 0) {
        return '';
    } else {
        return userdate($date, get_string('strftimedaydate'));
    }
}

/**
* Parameter $local added by power-web.at
* When local Time is needed the $local Param must be set to 1
* @param int $date a timestamp
* @param int $local
* @todo check consistence
* @return string printable time
*/
function scheduler_usertime($date, $local=0) {
    if ($date == 0) {
            return '';
    } else {
        if (!$timeformat = get_user_preferences('calendar_timeformat')) {
            $timeformat = get_string('strftimetime');
        }
        return userdate($date, $timeformat);
    }
}

/**
* get list of attendants for slot form
* @param int $cmid the course module
* @return array of moodle user records
*/
function scheduler_get_attendants($cmid){
    $context = get_context_instance(CONTEXT_MODULE, $cmid);
    $attendants = get_users_by_capability ($context, 'mod/scheduler:attend', 'u.id,lastname,firstname,email,picture', 'lastname', '', '', '', '', false, false, false);
    return $attendants;
}

/**
* Returns an array of slots that would overlap with this one.
* @param int $schedulerid the current activity module id
* @param int $starttimethe start of time slot as a timestamp
* @param int $endtime end of time slot as a timestamp
* @param int $teacher if not null, the id of the teacher constraint, 0 otherwise standas for "all teachers"
* @param int $others selects where to search for conflicts, [SCHEDULER_SELF, SCHEDULER_OTHERS, SCHEDULER_ALL]
* @param boolean $careexclusive if false, conflict will consider all slots wether exlusive or not. Use it for testing if user is appointed in the given scope.
* @uses $CFG
* @uses $DB
* @return array array of conflicting slots
*/
function scheduler_get_conflicts($schedulerid, $starttime, $endtime, $teacher=0, $student=0, $others=SCHEDULER_SELF, $careexclusive=true) {
    global $CFG, $DB;

    switch ($others){
        case SCHEDULER_SELF:
            $schedulerScope = " schedulerid = '{$schedulerid}' AND ";
            break;
        case SCHEDULER_OTHERS:
            $schedulerScope = " schedulerid != '{$schedulerid}' AND ";
            break;
        default:
            $schedulerScope = '';
    }
    $teacherScope = ($teacher != 0) ? " s.teacherid = '{$teacher}' AND " : '' ;
    $studentScope = ($student != 0) ? " a.studentid = '{$student}' AND " : '' ;
    $exclusiveClause = ($careexclusive) ? " exclusivity != 0 AND " : '' ;
    $sql = "
        SELECT
            s.*,
            a.studentid,
            a.id as appointmentid
        FROM
            {scheduler_slots} s
        LEFT JOIN
            {scheduler_appointment} a
        ON
            a.slotid = s.id
        WHERE
            {$schedulerScope}
            {$teacherScope}
            {$studentScope}
            {$exclusiveClause}
            ( (s.starttime <= {$starttime} AND
            s.starttime + s.duration * 60 > {$starttime}) OR
            (s.starttime < {$endtime} AND
            s.starttime + s.duration * 60 >= {$endtime}) OR
            (s.starttime >= {$starttime} AND
            s.starttime + s.duration * 60 <= {$endtime}) )
    ";
    $conflicting = $DB->get_records_sql($sql, NULL);

    return $conflicting;
}

/**
* Returns count of slots that would overlap with this
* use it as a test function before toggling to exclusive
* @param int $schedulerid the actual scheduler instance
* @param int $starttime the starttime identifying the slot
* @param int $endtime the endtime of the period
* @param int $teacher the teacher constraint, if null stands for "all teachers"
* @return int the number of compatible slots
* @uses $CFG
* @uses $DB
*/
function scheduler_get_consumed($schedulerid, $starttime, $endtime, $teacherid=0) {
    global $CFG, $DB;

    $teacherScope = ($teacherid != 0) ? " teacherid = '{$teacherid}' AND " : '' ;
    $sql = "
        SELECT
            COUNT(*)
        FROM
            {scheduler_slots} s,
            {scheduler_appointment} a
        WHERE
            a.slotid = s.id AND
            schedulerid = {$schedulerid} AND
            {$teacherScope}
            ( (s.starttime <= {$starttime} AND
            {$starttime} < s.starttime + s.duration * 60) OR
            (s.starttime < {$endtime} AND
            {$endtime} <= s.starttime + s.duration * 60) OR
            (s.starttime >= {$starttime} AND
            s.starttime + s.duration * 60 <= {$endtime}) )
    ";
    $count = $DB->count_records_sql($sql, NULL);
    return $count;
}

/**
* Returns the known exclusivity at that time
* @param int $schedulerid the actual scheduler instance
* @param int $starttime the starttime identifying the slot
* @return int the exclusivity value
* @uses $CFG
* @uses $DB
*/
function scheduler_get_exclusivity($schedulerid, $starttime) {
    global $CFG, $DB;

    $sql = '
        SELECT
            exclusivity
        FROM
            {scheduler_slots} s
        WHERE
            schedulerid = ? AND
            s.starttime <= ? AND
            ? <= s.starttime + s.duration * 60
    ';
    return $DB->get_field_sql($sql, array($schedulerid, $starttime, $starttime));
}

/**
* retreives the unappointed slots
* @param int $schedulerid
* @uses $CFG
* @uses $DB
*/
function scheduler_get_unappointed_slots($schedulerid){
    global $CFG, $DB;

    $sql = '
        SELECT
            s.*,
            MAX(a.studentid) AS appointed
        FROM
            {scheduler_slots} s
        LEFT JOIN
            {scheduler_appointment} a
        ON
            a.slotid = s.id
        WHERE
            s.schedulerid = ?
        GROUP BY
            s.id
        HAVING
            appointed = 0 OR appointed IS NULL
        ORDER BY
            s.starttime ASC
    ';
    $recs = $DB->get_records_sql($sql, array($schedulerid));
    return $recs;
}

/**
* retreives the available slots in several situations with a complex query
* @param int $studentid
* @param int $schedulerid
* @param boolean $studentside changes query if we are getting slots in student context
* @uses $CFG
* @uses $DB
*/
function scheduler_get_available_slots($studentid, $schedulerid, $studentside=false){
    global $CFG, $DB;

    // more compatible tryout
    $slots = $DB->get_records('scheduler_slots', array('schedulerid' => $schedulerid), 'starttime');
    $retainedslots = array();
    if ($slots){
        foreach($slots as $slot){
            $slot->population = $DB->count_records('scheduler_appointment', array('slotid' => $slot->id));
            $slot->appointed = ($slot->population > 0);
            $slot->attended = $DB->record_exists('scheduler_appointment', array('slotid' => $slot->id, 'attended' => 1));
            if ($studentside){
                $slot->appointedbyme = $DB->record_exists('scheduler_appointment', array('slotid' => $slot->id, 'studentid' => $studentid));
                if ($slot->appointedbyme) {
                    $retainedslots[] = $slot;
                    continue;
                }
            }
            // both side, slot is not complete
            if ($slot->exclusivity == 0 or ($slot->exclusivity > 0 and $slot->population < $slot->exclusivity)){
                $retainedslots[] = $slot;
                continue;
            }
        }
    }

    return $retainedslots;
}

/**
* checks if user has an appointment in this scheduler
* @param object $userlist
* @param object $scheduler
* @param boolean $student, if true, is a student, a teacher otherwise
* @param boolean $unattended, if true, only checks for unattended slots
* @param string $otherthan giving a slotid, excludes this slot from the search
* @uses $CFG
* @uses $DB
* @return the count of records
*/
function scheduler_has_slot($userlist, &$scheduler, $student=true, $unattended = false, $otherthan = 0){
    global $CFG, $DB;

    $userlist = str_replace(',', "','", $userlist);

    $unattendedClause = ($unattended) ? ' AND a.attended = 0 ' : '' ;
    $otherthanClause = ($otherthan) ? " AND a.slotid != $otherthan " : '' ;

    if ($student){
        $sql = "
            SELECT
                COUNT(*)
            FROM
                {scheduler_slots} s,
                {scheduler_appointment} a
            WHERE
                a.slotid = s.id AND
                s.schedulerid = ? AND
                a.studentid IN ('{$userlist}')
                $unattendedClause
                $otherthanClause
        ";
        return $DB->count_records_sql($sql, array($scheduler->id));
    } else {
        return $DB->count_records('scheduler_slots', array('teacherid' => $userlist, 'schedulerid' => $scheduler->id));
    }
}

/**
* returns an array of appointed user records for a certain slot.
* @param int $slotid
* @uses $CFG
* @uses $DB
* @return an array of users
*/
function scheduler_get_appointed($slotid){
    global $CFG, $DB;

    $sql = "
        SELECT
            u.*
        FROM
            {user} u,
            {scheduler_appointment} a
        WHERE
            u.id = a.studentid AND
            a.slotid = ?
    ";
    return $DB->get_records_sql($sql, array($slotid));
}

/**
* fully deletes a slot with all dependancies
* @param int slotid
* @uses $DB
*/
function scheduler_delete_slot($slotid){
    global $DB;
    
    if ($slot = $DB->get_record('scheduler_slots', array('id' => $slotid))) {
        scheduler_delete_calendar_events($slot);
    }
    if (!$DB->delete_records('scheduler_slots', array('id' => $slotid))) {
        print_error("Could not delete the slot from the database");
    }
    $DB->delete_records('scheduler_appointment', array('slotid' => $slotid));
}


/**
* get appointment records for a slot
* @param int $slotid
* @return an array of appointments
* @uses $CFG
* @uses $DB
*/
function scheduler_get_appointments($slotid){
    global $CFG, $DB;

    $apps = $DB->get_records('scheduler_appointment', array('slotid' => $slotid));

    return $apps;
}

/**
* a high level api function for deleting an appointement, and do
* what ever is needed
* @param int $appointmentid
* @param object $slot
* @param object $scheduler
* @uses $DB
*/
function scheduler_delete_appointment($appointmentid, $slot=null, $scheduler=null){
    global $DB;
    
    if (!$oldrecord = $DB->get_record('scheduler_appointment', array('id' => $appointmentid))) return ;

    if (!$slot){ // fetch optimization
        $slot = $DB->get_record('scheduler_slots', array('id' => $oldrecord->slotid));
    }
    if($slot){
        // delete appointment
        if (!$DB->delete_records('scheduler_appointment', array('id' => $appointmentid))) {
            print_error('Couldn\'t delete old choice from database');
        }
        // delete groupid in slot, if exists. // ULPGC ecastro, for group events
        $DB->set_field('scheduler_slots', 'groupid', 0, array('id' => $slot->id));

        // not reusable slot. Delete it if slot is too near and has no more appointments.
        if ($slot->reuse == 0) {
            if (!$scheduler){ // fetch optimization
                $scheduler = $DB->get_record('scheduler', array('id' => $slot->schedulerid));
            }
            $consumed = scheduler_get_consumed($slot->schedulerid, $slot->starttime, $slot->starttime + $slot->duration * 60);
            if (!$consumed){
                if (time() > 0 ) { //  ULPGC ecastro, volatiles are deleted always   $slot->starttime - $scheduler->reuseguardtime * 3600){
                    if (!$DB->delete_records('scheduler_slots', array('id' => $slot->id))) {
                        print_error('Couldn\'t delete old choice from database');
                    }
                }
            }
        }
    }
}

/**
* get the last considered location in this scheduler
* @param reference $scheduler
* @uses $USER
* @uses $DB
* @return the last known location for the current user (teacher)
*/
function scheduler_get_last_location(&$scheduler){
    global $USER, $DB;

    // we could have made an embedded query in Mysql 5.0
    $lastlocation = '';
    $select = "
            schedulerid = ? AND 
            teacherid = ? 
        GROUP BY timemodified
    ";
    $maxtime = $DB->get_field_select('scheduler_slots', 'MAX(timemodified)', $select, array($scheduler->id, $USER->id));
    if ($maxtime){
        $select = "
                schedulerid = :schedulerid AND 
                timemodified = :maxtime AND 
                teacherid = :userid 
            GROUP BY timemodified
        ";
        $maxid = $DB->get_field_select('scheduler_slots', 'MAX(timemodified)', $select, array('schedulerid' => $scheduler->id, 'maxtime' => $maxtime, 'userid' => $USER->id));
        $lastlocation = $DB->get_field('scheduler_slots', 'appointmentlocation', array('id' => $maxid));
    }
    return $lastlocation;
}

/**
* frees all slots unapppointed that are in the past
* @param int $schedulerid
* @param int $now give a date reference for measuring the "past" ! If 0, uses current time
* @uses $CFG
* @uses $DB
* @return void
*/
function scheduler_free_late_unused_slots($schedulerid, $now=0){
    global $CFG, $DB;

    if(!$now) {
        $now = time();
    }
    $sql = '
        SELECT DISTINCT
            s.id,s.id
        FROM
            {scheduler_slots} s
        LEFT JOIN
            {scheduler_appointment} a
        ON
          s.id = a.slotid
        WHERE
            a.studentid IS NULL AND
            s.schedulerid = ? AND
            starttime < ?
    ';
    $to_delete = $DB->get_records_sql($sql, array($schedulerid, $now));
    if ($to_delete){
        list($usql, $params) = $DB->get_in_or_equal($to_delete);
        $DB->delete_records_select('scheduler_slots', " id $usql ", $params);
    }
}

/// Events related functions

/**
* Updates events in the calendar to the information provided.
* If the events do not yet exist it creates them.
* The only argument this function requires is the complete database record of a scheduler slot.
* The course parameter should be the full record of the course for this scheduler so the
* teacher-title and student-title can be determined.
* @param object $slot the slot instance
* @param object $course the actual course
* @uses $DB
*/
function scheduler_add_update_calendar_events($slot, $course) {
    global $DB;

    //firstly, collect up the information we'll need no matter what.
    $eventDuration = ($slot->duration) * 60;
    $eventStartTime = $slot->starttime;

    // get all students attached to that slot
    $appointments = $DB->get_records('scheduler_appointment', array('slotid' => $slot->id), '', 'studentid,studentid');

    // nothing to do
    if (!$appointments) return;

    $schedulerDescription = $DB->get_field('scheduler', 'description', array('id' => $slot->schedulerid));
    $schedulerName = $DB->get_field('scheduler', 'name', array('id' => $slot->schedulerid));
    $teacherEventDescription = addslashes("$schedulerName<br/><br/>$schedulerDescription");

    $studentEventDescription = $teacherEventDescription;

    $teacher = $DB->get_record('user', array('id' => $slot->teacherid));

    /// First check and set group slots
    if(!empty($slot->groupid)) {
        $teacherEventType = "SSsup:{$slot->id}:{$course->id}";
        $studentEventType = "SSstu:{$slot->id}:{$course->id}";
        // passes studentEvent and teacherEvent by reference so function can fill them
        scheduler_events_exists($slot, $studentEvent, $teacherEvent);

        $group = $DB->get_record('groups', array('id' => $slot->groupid));
        $studentNames = array();
        if($members = groups_get_members($slot->groupid, 'u.id, u.lastname, u.firstname')) {
            foreach($members as $user) {
                $studentNames[]=fullname($user);
            }
        }
        $studentEventName = get_string('meetinggroup', 'scheduler', format_string($group->name));
        $studentEventDescription .= '<br />'.$studentEventName.
                                                        '<br />( '.implode(', ', $studentNames).' ). <br />'.get_string('staffhost', 'scheduler').': '.fullname($teacher).'. ';

        if ($studentEvent) {
            $studentEvent->name = $studentEventName;
            $studentEvent->description = $studentEventDescription;
            $studentEvent->format = 1;
            //$studentEvent->courseid = $course->id;
            $studentEvent->userid = 0; //$student->id;
            $studentEvent->groupid = $slot->groupid;
            $studentEvent->timemodified = time();
            // $studentEvent->modulename = 'scheduler'; // Issue on delete/edit link
            $studentEvent->instance = $slot->schedulerid;
            $studentEvent->timestart = $eventStartTime;
            $studentEvent->timeduration = $eventDuration;
            $studentEvent->visible = 1;
            $studentEvent->eventtype = $studentEventType;
            $DB->update_record('event', $studentEvent);
        } else {
            $studentEvent->name = $studentEventName;
            $studentEvent->description = $studentEventDescription;
            $studentEvent->format = 1;
            //$studentEvent->courseid = $course->id;
            $studentEvent->userid = 0; //$student->id;
            $studentEvent->groupid = $slot->groupid;
            $studentEvent->timemodified = time();
            // $studentEvent->modulename = 'scheduler';
            $studentEvent->instance = $slot->schedulerid;
            $studentEvent->timestart = $eventStartTime;
            $studentEvent->timeduration = $eventDuration;
            $studentEvent->visible = 1;
            $studentEvent->id = null;
            $studentEvent->eventtype = $studentEventType;
            // This should be changed to use add_event()
            $DB->insert_record('event', $studentEvent);
        }
        // no need for teacher event: either teacher is part of eth group or groups events are available to them
        return;
    }

    /// Now, regular single student/teacher eventsexit();
    $studentids = array_keys($appointments);
   // echo"<pre>";print_r($studentids);exit();
    $students = $DB->get_records_list('user', 'id', $studentids);

    //the eventtype field stores a code that is used to relate calendar events with the slots that 'own' them.
    //the code is SSstu (for a student event) or SSsup (for a teacher event).
    //then, the id of the scheduler slot that it belongs to.
    //finally, the courseID. I can't remember why, TODO: remember the good reason.
    //all in a colon delimited string. This will run into problems when the IDs of slots and courses are bigger than 7 digits in length...
    $teacherEventType = "SSsup:{$slot->id}:{$course->id}";
    $studentEventType = "SSstu:{$slot->id}:{$course->id}";

    $studentNames = array();

    // passes studentEvent and teacherEvent by reference so function can fill them
    scheduler_events_exists($slot, $studentEvent, $teacherEvent);

    foreach($students as $student){
        $studentNames[] = fullname($student);
        $studentEventName = get_string('meetingwith', 'scheduler').' '.$course->teacher.', '.fullname($teacher);

        //firstly, deal with the student's event
        //if it exists, update it, else create a new one.

        if ($studentEvent) {
            $studentEvent->name = $studentEventName;
            $studentEvent->description = $studentEventDescription;
            $studentEvent->format = 1;
            //$studentEvent->courseid = $course->id;
            $studentEvent->userid = $student->id;
            $studentEvent->timemodified = time();
            // $studentEvent->modulename = 'scheduler'; // Issue on delete/edit link
            $studentEvent->instance = $slot->schedulerid;
            $studentEvent->timestart = $eventStartTime;
            $studentEvent->timeduration = $eventDuration;
            $studentEvent->visible = 1;
            $studentEvent->eventtype = $studentEventType;
            $DB->update_record('event', $studentEvent);
        } else {
            $studentEvent->name = $studentEventName;
            $studentEvent->description = $studentEventDescription;
            $studentEvent->format = 1;
            //$studentEvent->courseid = $course->id;
            $studentEvent->userid = $student->id;
            $studentEvent->timemodified = time();
            // $studentEvent->modulename = 'scheduler';
            $studentEvent->instance = $slot->schedulerid;
            $studentEvent->timestart = $eventStartTime;
            $studentEvent->timeduration = $eventDuration;
            $studentEvent->visible = 1;
            $studentEvent->id = null;
            $studentEvent->eventtype = $studentEventType;
            // This should be changed to use add_event()
            $DB->insert_record('event', $studentEvent);
        }

    }

    if (count($studentNames) > 1){
        $teacherEventName = get_string('meetingwithplural', 'scheduler').' '.$course->students.', '.implode(', ', $studentNames);
    } else {
        $teacherEventName = get_string('meetingwith', 'scheduler').' '.$course->student.', '.$studentNames[0];
    }
    if ($teacherEvent) {
        $teacherEvent->name = $teacherEventName;
        $teacherEvent->description = $teacherEventDescription;
        $teacherEvent->format = 1;
        $teacherEvent->userid = $slot->teacherid;
        $teacherEvent->timemodified = time();
        // $teacherEvent->modulename = 'scheduler';
        $teacherEvent->instance = $slot->schedulerid;
        $teacherEvent->timestart = $eventStartTime;
        $teacherEvent->timeduration = $eventDuration;
        $teacherEvent->visible = 1;
        $teacherEvent->eventtype = $teacherEventType;
        $DB->update_record('event',$teacherEvent);
    } else {
        $teacherEvent->name = $teacherEventName;
        $teacherEvent->description = $teacherEventDescription;
        $teacherEvent->format = 1;
        $teacherEvent->userid = $slot->teacherid;
        $teacherEvent->instance = $slot->schedulerid;
        $teacherEvent->timemodified = time();
        // $teacherEvent->modulename = 'scheduler';
        $teacherEvent->timestart = $eventStartTime;
        $teacherEvent->timeduration = $eventDuration;
        $teacherEvent->visible = 1;
        $teacherEvent->id = null;
        $teacherEvent->eventtype = $teacherEventType;
        $DB->insert_record('event', $teacherEvent);
    }
}

/**
* Will delete calendar events for a given scheduler slot, and not complain if the record does not exist.
* The only argument this function requires is the complete database record of a scheduler slot.
* @param object $slot the slot instance
* @uses $CFG
* @uses $USER
* @uses $COURSE
* @uses $DB
* @return boolean true if success, false otherwise
*/
function scheduler_delete_calendar_events($slot) {
    global $CFG, $SITE, $COURSE, $DB;

    $scheduler = $DB->get_record('scheduler', array('id' => $slot->schedulerid));

    if (!$scheduler) return false ;

    $teacherEventType = "SSsup:{$slot->id}:{$scheduler->course}";
    $studentEventType = "SSstu:{$slot->id}:{$scheduler->course}";

    $teacherDeletionSuccess = $DB->delete_records('event', array('eventtype' => $teacherEventType));
    $studentDeletionSuccess = $DB->delete_records('event', array('eventtype' => $studentEventType));

    // we must fetch back all students identities as they may have been deleted
    $oldstudents = $DB->get_records('scheduler_appointment', array('slotid' => $slot->id), '', 'studentid, studentid');
    if ($scheduler->allownotifications && $oldstudents){
        foreach(array_keys($oldstudents) as $oldstudent){
            $student = $DB->get_record('user', array('id' => $oldstudent));
            $teacher = $DB->get_record('user', array('id' => $slot->teacherid));
            include_once($CFG->dirroot.'/mod/scheduler/mailtemplatelib.php');
            $vars = array( 'SITE' => $SITE->shortname,
                           'SITE_URL' => $CFG->wwwroot,
                           'COURSE_SHORT' => $COURSE->shortname,
                           'COURSE' => $COURSE->fullname,
                           'COURSE_URL' => $CFG->wwwroot.'/course/view.php?id='.$COURSE->id,
                           'MODULE' => $scheduler->name,
                           'USER' => fullname($student),
                           'DATE' => userdate($slot->starttime,get_string('strftimedate')),   // BUGFIX CONTRIB-937
 	                       'TIME' => userdate($slot->starttime,get_string('strftimetime')),   // BUGFIX end
                           'DURATION' => $slot->duration );
            $notification = compile_mail_template('cancelled', $vars );
            $notificationHtml = compile_mail_template('cancelled_html', $vars );
            email_to_user($teacher, $student, get_string('schedulecancelled', 'scheduler', $SITE->shortname), $notification, $notificationHtml);
        }
    }

    return ($teacherDeletionSuccess && $studentDeletionSuccess);
    //this return may not be meaningful if the delete records functions do not return anything meaningful.
}

/**
* This function decides if a slot should have calendar events associated with it,
* and calls the update/delete functions if neccessary.
* it must be passed the complete scheduler_slots record to function correctly.
* The course parameter should be the record that belongs to the course for this scheduler.
* @param object $slot the slot instance
* @param object $course the actual course
* @uses $DB
*/
function scheduler_events_update($slot, $course) {
    global $DB;

    $slotDoesntHaveAStudent = !$DB->count_records('scheduler_appointment', array('slotid' => $slot->id));
    $slotWasAttended = $DB->count_records('scheduler_appointment', array('slotid' => $slot->id, 'attended' => 1));

    if ($slotDoesntHaveAStudent || $slotWasAttended) {
        scheduler_delete_calendar_events($slot);
    }
    else {
        scheduler_add_update_calendar_events($slot, $course);
    }
}

/**
* This function sets the $studentSlot and $teacherSlot to the records of the calendar that relate
* to these scheduler slots. They will equal false if the records do not exist.
* it requires the full record of the scheduler slot supplied as $slot.
* @param object $slot the slot instance
* @param reference $studentSlot
* @param reference $teacherSlot
* @uses $DB
* @return void
*/
function scheduler_events_exists($slot, &$studentSlot, &$teacherSlot) {
    global $DB;

    //first we need to know the course that the scheduler belongs to...
    $courseid = $DB->get_field('scheduler', 'course', array('id' => $slot->schedulerid));

    //now try to fetch the event records...
    $teacherEventType = "SSsup:{$slot->id}:{$courseid}";
    $studentEventType = "SSstu:{$slot->id}:{$courseid}";

    $teacherSlot = $DB->get_record('event', array('eventtype' => $teacherEventType));
    $studentSlot = $DB->get_record('event', array('eventtype' => $studentEventType));
}

/**
* a utility function for making grading lists
* @param reference $scheduler
* @param string $id the form field id
* @param string $selected the selected value
* @param boolean $return if true, prints the list to output elsewhere returns the HTML string.
* @uses $DB
* @return the output of the choose_from_menu production
*/
function scheduler_make_grading_menu(&$scheduler, $id, $selected = '', $return = false){
    global $DB;
    
    if ($scheduler->scale > 0){
        for($i = $scheduler->scale ; $i >= 0 ; $i--)
            $scalegrades[$i] = $i;
    }
    else {
        $scaleid = - ($scheduler->scale);
        if ($scale = $DB->get_record('scale', array('id' => $scaleid))) {
            $scalegrades = make_menu_from_list($scale->scale);
        }
    }
    return choose_from_menu($scalegrades, $id, $selected, 'choose', '', '', $return);
}

/**
* adds an error css marker in case of matching error
* @param array $errors the current error set
* @param string $errorkey
*/
if (!function_exists('print_error_class')){
    function print_error_class($errors, $errorkeylist){
        if ($errors){
            foreach($errors as $anError){
                if ($anError->on == '') continue;
                if (preg_match("/\\b{$anError->on}\\b/" ,$errorkeylist)){
                    echo " class=\"formerror\" ";
                    return;
                }
            }
        }
    }
}

/**
* print top tabs
* @uses $USER
* @uses $DB
*/
function print_general_tabs($cm, $scheduler, $action='update') {
    global $USER, $DB;

    $tabrows = array();
    $row  = array();

    $tabname = get_string('myappointments', 'scheduler');
    $row[] = new tabobject($tabname, "view.php?id={$cm->id}&amp;page=myappointments", $tabname);

    if ($DB->count_records('scheduler_slots', array('schedulerid' => $scheduler->id)) > $DB->count_records('scheduler_slots', array('schedulerid' => $scheduler->id, 'teacherid' => $USER->id))) {
        $tabname = get_string('allappointments', 'scheduler');
        $row[] = new tabobject($tabname, "view.php?id={$cm->id}&amp;page=allappointments", $tabname);
    }

    $tabname = get_string('unscheduled', 'scheduler');
    $row[] = new tabobject($tabname, "view.php?id={$cm->id}&amp;what=unscheduled", $tabname);
    $tabname = get_string('datelist', 'scheduler');
    $row[] = new tabobject($tabname, "view.php?id={$cm->id}&amp;what=datelist", $tabname);
    $tabname = get_string('statistics', 'scheduler');
    $row[] = new tabobject($tabname, "view.php?what=viewstatistics&amp;id={$cm->id}&amp;course={$scheduler->course}&amp;page=overall", $tabname);
    $tabname = get_string('downloads', 'scheduler');
    $row[] = new tabobject($tabname, "view.php?what=downloads&amp;id={$cm->id}&amp;course={$scheduler->course}", $tabname);

    switch ($action){
        case 'allappointments':{
            $currenttab = get_string('allappointments', 'scheduler');
            break;
        }
        case 'myappointments':{
            $currenttab = get_string('myappointments', 'scheduler');
            break;
        }
        case 'viewstatistics':{
            $currenttab = get_string('statistics', 'scheduler');
            break;
        }
        case 'datelist':{
            $currenttab = get_string('datelist', 'scheduler');
            break;
        }
        case 'viewstudent':{
            $currenttab = get_string('studentdetails', 'scheduler');
            $row[] = new tabobject($currenttab, '', $currenttab);
            break;
        }
        case 'unscheduled':{
            $currenttab = get_string('unscheduled', 'scheduler');
            break;
        }
        case 'downloads':{
            $currenttab = get_string('downloads', 'scheduler');
            break;
        }
        case 'automatic':{
            $currenttab = get_string('automaticslots', 'scheduler');
            break;
        }
        default: {
            $currenttab = get_string('update', 'scheduler');
            $tabname = get_string('update', 'scheduler');
            $row[] = new tabobject($currenttab, '', $currenttab);
        }
    }

    if($scheduler->automaticslots) {
            $tabname = get_string('automaticslots', 'scheduler');
            $row[] = new tabobject($tabname, "view.php?what=automatic&amp;id={$cm->id}&amp;course={$scheduler->course}", $tabname);
    }


    $tabrows[] = $row;
    print_tabs($tabrows, $currenttab);
}


/**
* Calculate the amount of time a teacher has scheduled in a course
* @param int $timestart
* @param int $timeend
* @param int $teacherid
* @param int $courseid
* @uses $CFG
* @uses $DB
*/
function scheduler_scheduledtime_incourse($timestart, $timeend, $teacherid, $courseid) {
    global $CFG, $DB;

    $sql = "
        SELECT 
            sl.teacherid, 
            sl.schedulerid, 
            s.course, 
            SUM(sl.duration) AS totalduration
        FROM 
            {scheduler_slots} sl
        INNER JOIN 
            {scheduler} s 
        ON 
            s.id = sl.schedulerid
        WHERE  
            s.course = ?  AND 
            sl.teacherid = ? AND 
            ( (sl.starttime > ?) AND 
              ((sl.starttime + (sl.duration) * 60) < ? ))
        GROUP BY 
            sl.teacherid 
    ";
    if ($scheduledslots = $DB->get_records_sql($sql, array($courseid, $teacherid, $timestart, $timeend))) {
        $result = $scheduledslots[$teacherid];
        return $result->totalduration;
    }
    return 0;
}


/**
* inserts new slots with cron using automatic slots template
* @param int $starttime for the checking period
* @param int $endtime  for the checking period
* @param int $minduration  minimun combined duration of slots in the above period
* @uses $CFG
* @uses $DB
*/
function scheduler_cron_automatic_slots($timestart, $timeend, $minduration) {
    global $CFG, $DB;

    $sql = "
        SELECT 
            asl.id, 
            asl.schedulerid, 
            s.course, 
            asl.teacherid, 
            s.automaticslots
        FROM 
            {scheduler_automaticslots} asl
        INNER JOIN 
            {scheduler} s 
        ON 
            s.id = asl.schedulerid
        WHERE 
            s.automaticslots > 0
        GROUP BY 
            asl.schedulerid, 
            asl.teacherid, 
            s.course 
    ";

    // automaticslots=1 means using and copiying automatic slots, without limits
    // automaticslots=2 means enforcing a limit of using and copiying automatic slots, without limits

    if($scheduleteachers = $DB->get_records_sql($sql)) {

        foreach($scheduleteachers as $item) {
            $scheduled = -1;
            if($item->automaticslots == 2) { //
                $scheduled = scheduler_scheduledtime_incourse($timestart, $timeend, $item->teacherid, $item->course);
            }
            // If scheduled less that minimun then insert new slots
            if($scheduled < $minduration) {
                $select = " 
                    schedulerid = ? AND 
                    teacherid = ? 
                ";
                $automatics = $DB->get_records_select('scheduler_automaticslots', $select, array($item->schedulerid, $item->teacherid), 'starttime ASC');

                $start = strtotime('next Sunday', 0);
                $date = usergetdate($start);
                $referencetime = make_timestamp($date['year'], $date['mon'], $date['mday'] + 1);
                foreach($automatics as $aslot) {
                    $start = $timestart+$aslot->starttime - $referencetime;
                    $end = $timestart+$aslot->starttime - $referencetime + $aslot->duration * 60;
                    if(!$conflicts = scheduler_get_conflicts($aslot->schedulerid, $start, $end, $aslot->teacherid, 0, SCHEDULER_ALL, false)) {
                        $slot = clone($aslot);
                        $slot->id = null;
                        $slot->starttime = $start;
                        if($new = $DB->insert_record('scheduler_slots', $slot)) {
                            $scheduled += $aslot->duration;
                            if(($item->automaticslots == 2) && ($scheduled >= $minduration)) {
                                break 1; // breaking foreach automatics
                            }
                        }
                    }
                }
            }
        }
        $DB->set_field('config', 'value', $timestart,  array('name', 'sacheduler_lastcron'));
        $CFG->scheduler_lastcron = $timestart;
    }
    return true;
}

?>