<?PHP // $Id:
$string['pluginadministration'] = 'Scheduler administration';
$string['1daybefore'] = '1 day before slot';
$string['onedaybefore'] = '1 day before slot';
$string['1weekbefore'] = '1 week before slot';
$string['oneweekbefore'] = '1 week before slot';
$string['musthaveassignable'] = 'Assignable';
$string['alreadyappointed'] = 'Already Appointed';
$string['action'] = 'Action';
$string['addondays'] = 'Add Appointments on';
$string['addscheduled'] = 'Add scheduled student';
$string['addsession'] = 'Add slots';
$string['addsingleslot'] = 'Add single slot';
$string['addslot'] = 'You can at any time add additional appointment slots.';
$string['addstudenttogroup'] = 'Add this student to appointment group';
$string['allappointments'] = 'All Appointments';
$string['allowgroup'] = 'Exclusive slot - click to change';
$string['allslotsincloseddays'] = 'All slots were in closed days';
$string['allteachersgrading'] = 'Teachers can grade other\'s appointments.';
$string['appointfor'] = 'Appoint for';
$string['appointsolo'] = 'Just for me';
$string['appointingstudent'] = 'Appointment for slot';
$string['appointingstudentinnew'] = 'Appointment for new slot';
$string['appointmentnotes'] = 'Notes for appointment';
$string['appointments'] = 'Appointments';
$string['appointsomeone'] = 'Add new appointment';
$string['attendable'] = 'Attendable';
$string['attendablelbl'] = 'Total candidates for scheduling';
$string['attended'] = 'Attended';
$string['attendedlbl'] = 'Amount of attended students';
$string['attendedslots'] = 'Attended slots';
$string['automaticdurationhelp'] = 'This Scheduler is operating to enforce a minimum span of $a->min minutes per week offered in slots for students to appoint. <br />
Currently theer are defines slots for a totas interval od $a->current minutes ';
$string['automaticslots'] = 'Programmed slots';
$string['automaticslotshelp'] = 'Weekly template of predefined slots. If defined, these slots will be added weekly,
in an automatic way, to the current available slots table, with one week in advance.';
$string['automaticfree'] = 'Yes, wihout limit';
$string['automaticforce'] = 'Yes, with weekly minimun';
$string['availableslots'] = 'Available slots';
$string['availableslotsall'] = 'All slots';
$string['availableslotsnotowned'] = 'Not owned';
$string['availableslotsowned'] = 'Owned';
$string['bookwithteacher'] = 'Attendant';
$string['cancelledbystudent'] = '$a : Appointment cancelled or moved by a student';
$string['cancelledbyteacher'] = '$a : Appointment cancelled by the teacher';
$string['choice'] = 'Choice';
$string['chooseexisting'] = 'Choose existing';
$string['comments'] = 'Comments';
$string['complete'] = 'Booked';
$string['composeemail'] = 'Compose email:';
$string['configallteachersgrading'] = 'When enabled, teachers can grade appointments of students with other teachers.';
$string['configcronwday'] = 'Programmable slots are added weekly, on this week day';
$string['configexecuteatcron'] = 'Time of the day at which the weekly addition of programmable slots will take place';
$string['configminperiod'] = 'If set, programmable slots cron will try to add slots  to fulfill at leat this amount of time (minutes per week)';
$string['confirmdelete'] = 'Deletion is definitive. Continue anyway ?';
$string['conflictingslots'] = '$a Conflicting slots';
$string['conflictingslotsdel'] = '$a slots deleted to create new ones';
$string['cronwday'] = 'Cron week day';
$string['course'] = 'Course';
$string['csvencoding'] = 'File text encoding';
$string['csvfieldseparator'] = 'Field separator for csv';
$string['csvparms'] = 'csv format parameters';
$string['csvrecordseparator'] = 'Records separator for csv';
$string['cumulatedduration'] = 'Summed duration of appointements';
$string['date'] = 'From date ';
$string['datetime'] = 'Date';
$string['datelist'] = 'Schedule Overview';
$string['defaultslotduration'] = 'Default slot duration';
$string['deleteallslots'] = 'all slots';
$string['deleteallunusedslots'] = 'Delete all unused slots';
$string['deletedateslots'] = 'Delete by date';
$string['deletedslots'] = 'Deleted $a slots';
$string['deletemyslots'] = 'my unused slots';
$string['deleteondays'] = 'Delete slots on';
$string['deleteselection'] = 'Delete selection';
$string['deletetheseslots'] = 'Delete these slots';
$string['deleteunusedslots'] = 'unused slots';
$string['delsession'] = 'Delete slots';
$string['department'] = 'Department';
$string['disengage'] = 'Drop my appointments';
$string['displayfrom'] = 'Display appointment to students from';
$string['distributetoslot'] = 'Distribute to the whole group';
$string['divide'] = 'Divide into slots?';
$string['dontforgetsaveadvice'] = 'You have changed the list of appointed people. Don\'t forget saving this form to commit the changes definitively.';
$string['downloadexcel'] = 'Exports to Excel';
$string['downloads'] = 'Exports';
$string['duration'] = 'Duration';
$string['emailreminder'] = 'Email a reminder';
$string['end'] = 'End';
$string['enddate'] = 'Repeat Time Slot Until';
$string['endtime'] = 'End time';
$string['errorcantinsert'] = 'Can\'t insert in table $a';
$string['errorcantupdate'] = 'Can\'t update in table $a';
$string['errorinvalidslot'] = 'Slot ID invalid';
$string['errorcannotdeletedslots'] = 'Can\'t delete $a slots as required';
$string['exclusive'] = 'Exclusive';
$string['exclusivity'] = '';
$string['exclusivitylockedto'] = 'You cannot change the slot mode when scheduling. The current limit of the destination slot will apply. If the slot is new, a default limit of 1 will apply.';
$string['exclusivityoverload'] = '';
$string['explaingeneralconfig'] = 'These options can only be setup at site level and will apply to all schedulers of this Moodle.';
$string['exportinstructions'] = 'You should better save the generated export file on your hard drive before using it.';
$string['finalgrade'] = 'Final grade';
$string['firstslotavailable'] = 'First slot will be open on: ';
$string['forbidgroup'] = 'Group slot - click to change';
$string['forcegroupappoint'] = 'Force group appointments only';
$string['forceno'] = 'Individuals and groups';
$string['forceonlygroups'] = 'Groups appointments only';
$string['forceonlysingle'] = 'Individual appointments only';
$string['forcewhenoverlap'] = 'Force when overlap';
$string['forcourses'] = 'Choose students in courses';
$string['forduration'] = ' for $a min.';
$string['friday'] = 'Friday';
$string['generalconfig'] = 'General configuration';
$string['gradingstrategy'] = 'Grading strategy';
$string['groupbreakdown'] = 'By group size'; // @DYNA
$string['groupsession'] = 'Group Session';
$string['groupsize'] = 'Group size';
$string['guestscantdoanything'] = 'Guests can\'t do anything here.';
$string['howtoaddstudents'] = 'For adding students to a global scoped scheduler, use the role setting for the module.<br/>You may also use module role definitions to define the attenders of your students.';
$string['incourse'] = ' in course ';
$string['invitation'] = 'Invitation';
$string['invitationtext'] = 'Please choose a time-slot for an appointment at ';
$string['isattended'] = 'Meeting attended';
$string['isnoexclusive'] = 'Non exclusive';
$string['isnoexclusive'] = 'This slot is already selected more than once';
$string['lengthbreakdown'] = 'By slot duration'; // @DYNA
$string['limited'] = 'Limited ($a left)';
$string['location'] = 'Location';
$string['markseen'] = 'After you have had an appointment with a student please mark them as \"Seen\" by clicking the appropriate checkbox in the table above.';
$string['maxgrade'] = 'Take the highest grade';
$string['meangrade'] = 'Take the mean grade';
$string['meetinggroup'] = 'Meeting with your group: $a';
$string['meetingwith'] = 'Meeting with your';
$string['meetingwithplural'] = 'Meeting with your';
$string['minperiod'] = 'Minimun time enforced';
$string['minutes'] = 'minutes';
$string['minutesperslot'] = 'minutes per slot';
$string['missingstudents'] = '$a students still need to make an appointment';
$string['mode'] = 'Mode';
$string['modulename'] = 'Scheduler';
$string['modulenameplural'] = 'Schedulers';
$string['monday'] = 'Monday';
$string['move'] = 'Change';
$string['moveslot'] = 'Move slot';
$string['multiplestudents'] = 'Allow multiple students per slot?';
$string['myappointments'] = 'My Appointments';
$string['name'] = 'Scheduler name';
$string['negativerange'] = 'Range is negative. This can\'t be.';
$string['never'] = 'Never';
$string['newappointment'] = '$a : New appointment';
$string['noappointments'] = 'No appointments';
$string['nograde'] = 'No ratings';
$string['nogroups'] = 'No group available for scheduling.';
$string['noschedulers'] = 'There are no schedulers';
$string['noslots'] = 'There are no appointment slots available. Please contact your lecturer by email to arrange the appointment.';
$string['noslotsavailable'] = 'No appointement required, or all the announced appointments are complete.';
$string['noslotsopennow'] = 'No slots are open right now.';
$string['nostudents'] = 'No students appointed';
$string['nostudenttobook'] = 'No student to book';
$string['note'] = 'Grade';
$string['noteacherforslot'] = 'No teacher forthe slots';
$string['noteachershere'] = 'No teacher available';
$string['notes'] = 'Comments';
$string['notifications'] = 'Notifications';
$string['notselected'] = 'You have not yet made a choice';
$string['now'] = 'Now';
$string['occurrences'] = 'Occurrences';
$string['on'] = 'on';
$string['oneappointmentonly'] = 'Students can only register one appointment';
$string['oneatatime'] = 'Students can only register one appointment at a time';
$string['oneslotadded'] = '1 slot added';
$string['onthemorningofappointment'] = 'On the morning of the appointment';
$string['overall'] = 'Overall';
$string['overlappings'] = 'Some other slots are overlapping';
$string['registeredlbl'] = 'Student appointed';
$string['reminder'] = 'Reminder';
$string['remindertext'] = 'This is just a reminder that you have not yet set up your appointment. Please choose a time-slot as soon as possible at ';
$string['remindwhere'] = 'Location of the appointement: ';
$string['remindwithwhom'] = 'Scheduled Appointment with ';
$string['resetschedulers'] = 'Delete scheduler data ';
$string['return'] = 'Back to course';
$string['reuse'] = 'Reuse this slot';
$string['reuseguardtime'] = 'Reuse guard time';
$string['revoke'] = 'Revoke the appointement';
$string['saturday'] = 'Saturday';
$string['save'] = 'Save';
$string['savechoice'] = 'Save my choice';
$string['savecomment'] = 'Save the comment';
$string['saveseen'] = 'Save seen';
$string['schedule'] = 'Schedule';
$string['scheduleappointment'] = 'Schedule appointment for ';
$string['schedulecancelled'] = '$a : Your appointment cancelled or moved';
$string['schedulegroups'] = 'Schedule by group';
$string['scheduler:appoint'] = 'Appoint';
$string['scheduler:attend'] = 'Attend students';
$string['scheduler:canscheduletootherteachers'] = 'Schedule appointments for other staff members';
$string['scheduler:disengage'] = 'Drop all appointments (students)';
$string['scheduler:manage'] = 'Manage your slots and appointments';
$string['scheduler:manageallappointments'] = 'Manage all scheduler data';
$string['scheduler:seeotherstudentsbooking'] = 'See other student booking on the slot';
$string['scheduler:seeotherstudentsresults'] = 'See other slot student\'s result';
$string['schedulestudents'] = 'Schedule by student';
$string['seen'] = 'Seen';
$string['setreused'] = 'Set reusable';
$string['setunreused'] = 'Set volatile';
$string['slot_is_just_in_use'] = 'Sorry, the appointment has just been chosen by another student!<br>Please try again.';
$string['slots'] = 'Slots';
$string['slotsadded'] = ' slots have been added';
$string['slottype'] = 'Slot type';
$string['slotupdated'] = '1 slot updated';
$string['slotwarning'] = '<b>Warning: </b>Moving this slot to the selected time will require that the following slot(s) are removed...';
$string['staffbreakdown'] = 'By '; // @DYNA
$string['staffhost'] = 'Host';
$string['staffmember'] = 'Member of Staff';
$string['staffrolename'] = 'Role name of the attendant';
$string['start'] = 'Start';
$string['startpast'] = 'You can\'t start an appointment slot in the past';
$string['starttime'] = 'Start time';
$string['statistics'] = 'Statistics';
$string['strdownloadcsvgrades'] = 'CVS Export of grades';
$string['strdownloadcsvslots'] = 'CVS Export of slots';
$string['strdownloadexcelsingle'] = 'Excel export as one sheet';
$string['strdownloadexcelteachers'] = 'Excel export by ';
$string['strdownloadodssingle'] = 'OpenDoc export as one sheet';
$string['strdownloadodsteachers'] = 'OpenDoc export by ';
$string['student'] = 'Student';
$string['studentbreakdown'] = 'By student'; // @DYNA
$string['studentcomments'] = 'Student\'s notes';
$string['studentdetails'] = 'Student Details';
$string['studentnotes'] = 'Your notes about&nbsp;&nbsp;<br/> the appointment ';
$string['students'] = 'Students';
$string['sunday'] = 'Sunday';
$string['thursday'] = 'Thursday';
$string['tuesday'] = 'Tuesday';
$string['unattended'] = 'Unattended';
$string['unscheduled'] = 'Unscheduled students';
$string['unlimited'] = 'Unlimited';
$string['unregisteredlbl'] = 'Unappointed students';
$string['updategrades'] = 'Update grades';
$string['updatenotes'] = 'Update notes';
$string['updatesingleslot'] = '';
$string['updatingappointment'] = 'Updating an appointment';
$string['wednesday'] = 'Wednesday';
$string['welcomebackstudent'] = 'The bold line in the table below highlights your chosen appointment time. You can change to any other available slot.';
$string['welcomenewstudent'] = 'The table below shows all available slots for an appointment. Make your choice by selecting a radiobutton and don\'t forget to click on \"Save my choice\" afterwards. If you need to make a change later you can revisit this page.';
$string['welcomenewteacher'] = 'Please click on the button below to add appointment slots to see all your students.';
$string['what'] = 'Prompt';
$string['whosthere'] = 'current participants';
$string['xdaysbefore'] = ' days before slot';
$string['xweeksbefore'] = ' weeks before slot';
$string['yourappointmentnote'] = 'Comments for your eyes';
$string['yourslotnotes'] = 'Comments on the meeting';
$string['noresults'] = 'No results found';
$string['forcewhenoverlap_help']='<h2>Scheduler</h2>
<h3>Forcing slots addition through a session</h3>
<p>This control allows forcing the addition of slots when the session conflicts with other slots. 
In that case, only "clean" slots will be added. Conflicting will be ignored.</p>

<p>
If not used, the addition procedure will block when overlapping are detected, and you will asked for
deleting previous slots before the procedure can add new slots.
</p>';
$string['addscheduled_help']='<h2>Scheduler</h2>
<h3>Adding an appointment on slot setup</h3>
<p>Using this link, you will add a user to the appointment list defined by this slot information. It may be a simple and fast way to setup a collective appointment. </p>';
$string['appointmentmode_help']='<h2>Scheduler</h2>
<h3>Setting appointment mode</h3>
<p>You may choose here some variants in the way appointments can be taken. </p>
<p><ul>
<li><b>"One single appointment" mode:</b> The student can only have a single appointment in this module. Once it has been seen by the attendant, he will not be allowed to apply for any further meeting. The only way to reset ability of a student to apply is to delete the old "seen" records.</li>
<li><b>"One at a time" mode:</b> The student can apply only to one (future) date. Once the meeting is over and concluded, he can appoint back. this mode is usefull to arbitrate project appointments on long run projects, specially when multiple phases of appointements are to be offered. 
</li>
</ul>
</p>';
$string['bookwithteacher_help']='<h2>Scheduler</h2>
<h3>Choosing a staff role member</h3>
<p>You may choose here an attendant for the appointment. </p>';
$string['choosingslotstart_help']="<h2>Scheduler</h2>
<h3>Choosing the start time</h3>
<p>Change (or choose) the appointement start time. If this appointement collides with some other slots, you'll be asked
if this slot replaces all conflicting appointements. Note that the new slot parameters will override all previous
settings.</p>";
$string['exclusivity_help']='<h2>Scheduler</h2>
<h3>Setting a limit for the number of appointments</h3>
<p>You can set a limit on the amount of students that can apply for a given slot. </p>
<p>Setting aliit of 1 (default) will toggle the slot in exclusive mode</p>
<p>If the slot is set to unlimited number (0), this slot will never be considered in constraints evaluation, even if other slots are exclusive or limited in the same time range.
</p>';
$string['forcewhenoverlap_help']='<h2>Scheduler</h2>
<h3>Forcing slots addition through a session</h3>
<p>This control allows forcing the addition of slots when the session conflicts with other slots. 
In that case, only "clean" slots will be added. Conflicting will be ignored.</p>

<p>
If not used, the addition procedure will block when overlapping are detected, and you will asked for
deleting previous slots before the procedure can add new slots.
</p>';
$string['location_help']='<h2>Scheduler</h2>
<h3>Setting physical location for the meeting</h3>
<p>Tell here the expected location of the meeting.</p>';
/*$string['mods_help']='<img alt="'.print_string('modulename', 'scheduler').'" valign="middle" src="'.$CFG->wwwroot.'/mod/scheduler/icon.gif">
&nbsp;<b>'. print_string('modulename', 'scheduler').'</b></b>

<ul>
<p>
This module helps you to schedule one-on-one appointments with all your students. 
You specify the periods during which you are available to see the students and 
the length of each appointment. The students then book themselves into one of 
the available timeslots. The module also lets you record the attendance.
</p>
<p>
This module checks conflict constraints across scheduler instances. This means that
an appointment within a course could generate a constraint on slots in another course.
</p>
</ul>';
*/$string['notifications_help']='<h2>Scheduler</h2>
<h3>Activating mail notifications</h3>
<p>When this option is enabled, attendants and students will receive notifications when appointments are applied for or cancelled. </p>';
$string['reuse_help']='<h2>Scheduler</h2>
<h3>Slots volatility</h3>
<p>
A <i>reuseable</i> slot will remain in the scheduler even a student or the teacher revokes an appointment. The freed slot is available again for appointing.</p>

<p>A <i>volatile</i> slot will be automatically deleted in the above cases if it has to start to close to the current dat (it is considered you may not want to add a constraint so close to "right now"). The guard delay can be set by the instance-scoped configuration parameter "Reuse guard time".
</p>';
$string['reuseguardtime_help']='<h2>Scheduler</h2>
<h3>Reuse guard time</h3>
<p>This parameter sets up the guard time for keeping volatile slots.</p>
<p>When a slot is declared as volatile (not reusable), it will be automatically deleted when a student changes is appointment assignation, feeing completely the slot, or when a teacher revokes all appointments on it. The deletion takes place when the slot starts too close to the actual date.<p>
<p>The parameter specifies the delay, from "now on", under which a freed slot will be deleted and will not be available for further appointments.</p>';
$string['staffrolename_help']='<h2>Scheduler</h2>
<h3>Setting a role name for the staff member</h3>
<p>The label for the role who attends students. This is not necessarily a "teacher". This name can contain multilang marking.</p>';


?>